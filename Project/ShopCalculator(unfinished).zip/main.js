let unitArr = [];
//let unitPrice = {"মুলাম":10,"পেড":20,"হার্ড":30,"লোহা":40, "তামা":50,"সিলবার":60};
let unitPrice = JSON.parse(localStorage.getItem('unitPrice'));
if (unitPrice === null) {
  unitPrice = {};
  localStorage.setItem("unitPrice", JSON.stringify(unitPrice));
}
let savedList = JSON.parse(localStorage.getItem("savedList"));
if (savedList == null) {
  savedList = [];
  localStorage.setItem("savedList", JSON.stringify(savedList));
}
class mainManu {
  constructor() {}
  initializeMainManu() {
    document.querySelector('body').innerHTML = `
        <div onclick="cluObj.initializeCalculator()" class="btn">সিলিপ</div>
      <div onclick="priObj.initializePrices()" class="btn">মালেরদাম</div>
      <div onclick="saveObj.initializeSaved()" class="btn">সেভকরাসিলিপ</div>
      <div onclick="employObj.initializeEmployeesList()" class="btn">হকারলিস্ট</div>
        `;
    unitArr = [];
  }
}
class calculator {
  constructor() {}
  initializeCalculator() {
    this.employeesList = JSON.parse(localStorage.getItem("employees"));
    document.querySelector('body').innerHTML = `
    <button onclick="mainObj.initializeMainManu()">Back</button>
    <div id="employee"></div>
    <div id="container">
    </div> <div id = "totalPriceContainer" > </div>
    <div onclick="saveObj.save()">Save</div>
    <div onclick="printObj.print()">Chart</div>`;
    this.totalPriceContainer = document.getElementById("totalPriceContainer");
    this.container = document.getElementById("container");
    this.keys = Object.keys(unitPrice);
    this.unitElement = document.createElement("div");
    this.unitElement.className = "unit";
    this.selectEmployee = document.createElement("select");
    this.selectEmployee.classList.add("selectEmployee");
    this.employeesList.forEach((e) => {
      this.optionEmployee = document.createElement("option");
      this.optionEmployee.innerText = e;
      this.selectEmployee.appendChild(this.optionEmployee);
    })
    this.selectElement = document.createElement("select");
    this.selectElement.className = "goods";
    this.selectElement.setAttribute("onclick", "cluObj.createAmountField(this)");
    this.selectElement.setAttribute("onchange", "cluObj.OnChange(this)");
    this.keys.forEach((e) => {
      this.optionElement = document.createElement("option");
      this.optionElement.innerText = e;
      this.selectElement.appendChild(this.optionElement);
    })
    this.unitElement.appendChild(this.selectElement);
    document.getElementById("employee").appendChild(this.selectEmployee);
    this.container.appendChild(this.unitElement);

    this.amountArr = [];
  }
  createAmountField(e) {
    parent = e.parentNode;
    if (unitArr.includes(parent)) {} else {
      let ele = document.createElement("input");
      ele.className = "amount";
      ele.setAttribute("onkeypress", "cluObj.addUnit(event,this)");
      ele.setAttribute("type", "number");
      parent.appendChild(ele);
      unitArr.push(parent);
    }
  }
  OnChange(e) {
    let obj = e.parentNode.children[2];
    let childs = {};
    let totalValue = 0;
    if (obj === undefined) {} else {
      obj = e.parentNode.children[1];
      childs = obj.parentNode.children;
      childs[2].innerText = String(parseInt(obj.value * unitPrice[this.detectGoods(e)]));
      totalValue = 0;
      unitArr.forEach((e) => {
        totalValue += parseInt(e.children[2].innerText);
      })
      this.totalPriceContainer.innerText = totalValue;
    }
  }
  detectGoods(e) {
    var value = e.options[e.selectedIndex].value;
    var text = e.options[e.selectedIndex].text;
    return text
  }
  addUnit(e, obj) {
    if (e.keyCode === 13) {
      if (this.amountArr.includes(obj)) {} else {
        let element1 = document.createElement("div");
        element1.className = "price";

        element1.innerText = String(parseInt(obj.value * unitPrice[this.detectGoods(obj.parentNode.children[0])]));
        obj.parentNode.appendChild(element1);

        this.amountArr.push(obj);

        this.container.innerHTML = "";
        unitArr.forEach((e) => {
          this.container.appendChild(e);
        })
        this.totalPriceContainer = document.getElementById("totalPriceContainer");
        this.container = document.getElementById("container");
        this.keys = Object.keys(unitPrice);
        this.unitElement = document.createElement("div");
        this.unitElement.className = "unit";
        this.selectElement = document.createElement("select");
        this.selectElement.className = "goods";
        this.selectElement.setAttribute("onclick", "cluObj.createAmountField(this)");
        this.selectElement.setAttribute("onchange", "cluObj.OnChange(this)");
        this.keys.forEach((e) => {
          this.optionElement = document.createElement("option");
          this.optionElement.innerText = e;
          this.selectElement.appendChild(this.optionElement);
        })
        this.unitElement.appendChild(this.selectElement);
        this.container.appendChild(this.unitElement);

        let totalValue = 0;
        unitArr.forEach((e) => {
          totalValue += parseInt(e.children[2].innerText);
        })
        this.totalPriceContainer.innerText = totalValue;

      }
      obj.addEventListener("input", () => {
        let childs = obj.parentNode.children;
        childs[2].innerText = String(parseInt(obj.value * unitPrice[this.detectGoods(obj.parentNode.children[0])]));
        let totalValue = 0;
        unitArr.forEach((e) => {
          totalValue += parseInt(e.children[2].innerText);
        })
        this.totalPriceContainer.innerText = totalValue;
      })
      obj.blur();
    }
  }
}
class prices {
  constructor() {}
  initializePrices() {
    document.body.innerHTML = "<div><button onclick='mainObj.initializeMainManu()'>Back</button></div>";
    let container = document.createElement('div');
    container.classList.add('priceContainer');
    let addGoods = document.createElement('div');
    addGoods.classList.add('addGoods');
    addGoods.innerHTML = "Add";
    addGoods.setAttribute("onclick", "priObj.addGoods()")
    document.body.appendChild(container);
    document.body.appendChild(addGoods);
    let keys = Object.keys(unitPrice);
    keys.forEach((e) => {
      let element1 = document.createElement('div');
      let element2 = document.createElement('span');
      let element3 = document.createElement('span');
      let element4 = document.createElement('input');
      let element5 = document.createElement('span');
      let element6 = document.createElement('span');
      element2.innerText = e;
      element3.innerText = '=';
      element4.value = unitPrice[e];
      element5.innerText = "Save";
      element5.setAttribute("onclick", "priObj.changePrize(this)");
      element6.innerText = "Delete";
      element6.setAttribute("onclick", "priObj.deleteGoods(this)");
      element1.appendChild(element2);
      element1.appendChild(element3);
      element1.appendChild(element4);
      element1.appendChild(element5);
      element1.appendChild(element6);
      element1.appendChild(document.createElement('br'));
      container.appendChild(element1);
    });
  }
  changePrize(e) {
    let selectedGoods = e.parentNode.children[0];
    let selectedPrize = e.parentNode.children[2].value;
    unitPrice[selectedGoods.innerText] = Number(selectedPrize);
    localStorage.setItem("unitPrice", JSON.stringify(unitPrice));
  }
  addGoods() {
    let name = prompt("  মালের নাম?");
    if (name === null) {}
    else if (name.length < 3) {
      alert("নামটি সঠিক নয়!");
    } else {
      unitPrice[name] = 0;
      localStorage.setItem("unitPrice", JSON.stringify(unitPrice));
      this.initializePrices();
    }
  }
  deleteGoods(e) {
    let selectedGoods = e.parentNode.children[0].innerText;
    delete unitPrice[selectedGoods];
    localStorage.setItem("unitPrice", JSON.stringify(unitPrice));
    this.initializePrices();
  }
}
class saved {
  constructor() {}
  initializeSaved() {
    document.body.innerHTML = "<div><button onclick='mainObj.initializeMainManu()'>Back</button></div><p>Coming soon!</p>";
  }
  save() {
    let currentCalculation = utileObj.getCurrentCalculationObject();
    savedList.push(currentCalculation);
    if(savedList.length > 100){
      savedList.splice(0,1);
    }
    localStorage.setItem("savedList",JSON.stringify(savedList));
  }
}
class employees {
  constructor() {}
  initializeEmployeesList() {
    let employees = JSON.parse(localStorage.getItem("employees"));
    document.body.innerHTML = "<div><button onclick='mainObj.initializeMainManu()'>Back</button></div>";
    let container = document.createElement("div");
    let addBtn = document.createElement("div");
    container.classList.add("container");
    addBtn.setAttribute("onclick", "employObj.addEmployees()");
    addBtn.classList.add("addBtn");
    addBtn.innerText = "Add Employee";
    document.body.appendChild(container);
    document.body.appendChild(addBtn);

    if (employees) {
      employees.forEach((e, i) => {
        let element1 = document.createElement('div');
        let element2 = document.createElement('span');
        element1.innerText = e;
        element2.innerText = "delete";
        element2.value = i;
        element2.setAttribute("onclick", "employObj.deleteEmployee(this)")
        container.appendChild(element1);
        container.appendChild(element2);
      })
    } else {
      container.innerText = "Employees not found";
    }
  }
  addEmployees() {
    let employees = JSON.parse(localStorage.getItem("employees"))
    if (employees) {} else { employees = [] }
    let name = prompt("   হকারের নাম: ");
    if (name) { employees.push(name) }
    localStorage.setItem("employees", JSON.stringify(employees));
    this.initializeEmployeesList();
  }
  deleteEmployee(e) {
    let employees = JSON.parse(localStorage.getItem("employees"))
    employees.splice(e.value, 1);
    localStorage.setItem("employees", JSON.stringify(employees));
    this.initializeEmployeesList();
  }
}
class calculationPrint{
  constructor(){}
  print(e = null){
    if(e === null){e = utileObj.getCurrentCalculationObject()}
    document.querySelector("body").innerHTML = `
    <div id="printContainer">
     <div id='printName'>${e.name}</div>
     <div id='printDate'>${e.date}</div>
     <div id='printMainContent'>
     
     </div>
     <div id="printTotalPriceContainer"></div>
    </div>
    `;
    this.container = document.getElementById("printContainer");
    this.printMainContent = document.getElementById("printMainContent");
    e['value'].forEach((ele,index)=>{
      let element = document.createElement('div');
      let element1 = document.createElement('span');
      let element2 = document.createElement('span');
      let element3 = document.createElement('span');
      
      element1.innerText = e['goods'][index];
      element2.innerText = e['amounts'][index];
      element3.innerText = e['value'][index];
      
      element.appendChild(element1);
      element.appendChild(element2);
      element.appendChild(element3);
      
      printMainContent.appendChild(element);
    })
    document.getElementById('printTotalPriceContainer').innerText = e['totalValue'];
  }
}
class utility {
  constructor() {}
  getCurrentCalculationObject() {
    let obj = {}
    let name = cluObj.selectEmployee[cluObj.selectEmployee.selectedIndex].text;
    let date = this.getCurrentTimeInFormat();
    let goods = this.getGoodsArray();
    let amounts = this.getAmountArray();
    let value = this.getValueArray();
    let totalValue = cluObj.totalPriceContainer.innerText;
    if (name && date && goods && amounts && value && totalValue) {
      obj = {
        name: name,
        date: date,
        goods: goods,
        amounts: amounts,
        value: value,
        totalValue: totalValue
      }
    } else {
      return null;
    }
    return obj;
  }
  getCurrentTimeInFormat() {
    const d = new Date;
    Number.prototype.padLeft = function(base, chr) {
      var len = (String(base || 10).length - String(this).length) + 1;
      return len > 0 ? new Array(len).join(chr || '0') + this : this;
    }

    let dformat1 = [(d.getMonth() + 1).padLeft(),
               d.getDate().padLeft(),
               d.getFullYear()].join('/') + ' ' + [d.getHours().padLeft(),
               d.getMinutes().padLeft(),
               d.getSeconds().padLeft()].join(':');
    return dformat1;
  }
  getGoodsArray() {
    let temp = [];
    unitArr.forEach((e) => {
      temp.push(e.children[0].value);
    })
    return temp;
  }
  getAmountArray() {
    let temp = [];
    unitArr.forEach((e) => {
      temp.push(e.children[1].value);
    })
    return temp;
  }
  getValueArray() {
    let temp = [];
    unitArr.forEach((e) => {
      temp.push(e.children[2].innerText);
    })
    return temp;
  }
}

const mainObj = new mainManu();
const cluObj = new calculator();
const priObj = new prices();
const saveObj = new saved();
const employObj = new employees();
const utileObj = new utility();
const printObj = new calculationPrint();
mainObj.initializeMainManu();
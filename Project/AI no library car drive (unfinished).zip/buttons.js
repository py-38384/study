function leftBtn(ele) {
  controls.changeDirectionPub('left');
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none';
  }, 100);
}

//Right Button button functionality
function rightBtn(ele) {
  controls.changeDirectionPub('right');
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none';
  }, 100);
}

//Top Button button functionality
function topBtn(ele) {
  controls.changeDirectionPub('forward');
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
}

//Bottom Button button functionality
function bottomBtn(ele) {
  controls.changeDirectionPub('reverse');
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
}

//pause button functionality
function pauseGame(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
}

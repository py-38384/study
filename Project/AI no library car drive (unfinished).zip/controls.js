class Controls{
  constructor(){
    this.forward = false;
    this.left = false;
    this.right = false;
    this.reverse = false;
  }
  changeDirectionPub(dir){
    this.#changeDirectionPubPri(dir);
  }
  #changeDirectionPubPri(dir){
    switch(dir){
      case 'left':
          if(this.right){
            this.right = false;
          }else{
            this.right = false;
            this.left = true;
          }
        break;
      case 'right':
          if (this.left) {
            this.left = false;
          } else {
            this.right = true;
            this.left = false;
          }
        break;
      case 'forward':
        if (this.reverse) {
          this.reverse = false;
        } else {
          this.forward = true;
          this.reverse = false;
        }
        break;
      case 'reverse':
        if (this.forward) {
          this.forward = false;
        } else {
          this.forward = false;
          this.reverse = true;
        }
        break;
    }
  }
}

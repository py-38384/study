function larp(a,b,c){
  return a+(b-a)*c;
}

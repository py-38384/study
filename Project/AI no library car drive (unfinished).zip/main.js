let btn_outline = '5px solid #8AC8FF';
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');
const controls = new Controls();
const road = new Road(canvas.width/2,canvas.width*0.90);
const car = new Car(road.getLaneMid(1),150,40,60,controls);
canvas.width = 300;

animate();

function animate(){
  canvas.height = window.innerHeight-300;
  ctx.save();
  ctx.translate(0,-car.y+canvas.width*1.2);
  car.update();
  road.draw(ctx);
  car.drow(ctx);
  ctx.restore();
  window.requestAnimationFrame(animate);
}

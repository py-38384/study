<?php
$url = "localhost";
$name = "u319998838_roydas";
$pass = "2HglSmG~";
$database = "u319998838_smartdata";

$connect = mysqli_connect($url,$name,$pass,$database);

if(!$connect){
    die("Databese not connected".mysqli_connect_error());
}
// echo "Databese conected";
?>
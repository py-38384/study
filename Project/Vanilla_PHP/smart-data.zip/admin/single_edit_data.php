<?php
function check()
{
    if (isset($_COOKIE["user"])) {
        if ($_COOKIE["user"] == "misterBot") {}
        else if ($_COOKIE["user"] == "null") {
            header("Location: index.php");
        } else {
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");
        }
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
}
check();
    include "../config.php";
    $id = $_GET['lead_id'];
    $sql = mysqli_query($connect,"SELECT * FROM `data` WHERE `id` = $id");
    $row = mysqli_fetch_assoc($sql);
    $experience_array = explode('~', $row['experience'],);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Portfolio</title>
    <link rel="stylesheet" href="water.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'sans-serif';
        }

        header {
            position: absolute;
            top: 6%;
            font-size: 30px;
            color: white;
        }
        body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: column;
            min-height: 100vh;
            background-color: #424242;
        }

        .alert {
            width: 40%;
            height: 4%;
            min-width: 300px;
            display: none;
            justify-content: center;
            align-items: center;
            border-radius: 5px;
            position: absolute;
            top: 12%;
        }
        .alert-denger{
            color: red;
            border: 1px solid red;
        }
        .alert-success{
            color: green;
            border: 1px solid green;
        }

        form {
            display: flex;
            justify-content: center;
            flex-direction: column;
            width: 80%;
            position: relative;
            min-height: 100%;
            top: 130px;
            gap: 10px;
            padding-bottom: 40px;
        }

        form div {
            height: 6%;
            flex-grow: 1;
            min-height: 50px;
        }

        form div input {
            width: 100%;
            height: 100%;
            padding: 10px;
            background-color: white;
            color: black;
        }

        form div textarea {
            resize: none;
            background-color: white;
            color: black;
        }

        form .project-small-description {
            flex-grow: 4;
        }

        form div button {
            width: 20%;
            min-width: 120px;
            height: 100%;
            background-color: white;
            color: black;
        }
        form .buttons a {
            text-decoration: none;
            width: 20%;
            height: 40px;
            min-width: 120px;
            padding: 10px;
            border-radius: 5px;
            height: 100%;
            background-color: white;
            color: black;
            padding-top: 12px;
            margin-top: 0;
        }
        form .buttons a:hover{
            background-color: black;
            color: red;
        }
        .buttons button:hover{
            color: white;
        }
        .back-btn{
            color: white;
            position: absolute;
            top: 4%;
        }
        .buttons{
            display: flex;
            align-items: center;
            justify-content: flex-start;
        }

        /* @media (max-height: 950px) {
            form {
                height: 46.8%;
            }
        }
        @media (max-height: 800px) {
            form {
                height: 52%;
            }
        }
        @media (max-height: 700px) {
            form {
                height: 58.8%;
            }
        } */
    </style>
</head>

<body>
    <header>Add data</header>
    <a href="index.php" class="btn back-btn">back to admin panel</a>
    <div class="alert alert-denger" style="display:<?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["status"])){if($_GET["status"] == "error"){echo "flex";}else{echo "none";}}else{echo "none";}}else{echo "none";}?>"><?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["alert"])){if($_GET["status"] == "error"){echo $_GET["alert"];}else{echo "";}}else{echo "";}}else{echo "";}?></div>
    <div class="alert alert-success" style="display: <?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["status"])){if($_GET["status"] == "success"){echo "flex";}else{echo "none";}}else{echo "none";}}else{echo "none";}?>"><?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["alert"])){if($_GET["status"] == "success"){echo $_GET["alert"];}else{echo "";}}else{echo "";}}else{echo "";}?></div>
    <form action="single_edit_data_handler.php" method="post" enctype="multipart/form-data">
        <h3>NAME:</h3>
        <div class="Full-name"><input type="text" name="fullname" value="<?php echo $row["fullname"];?>" placeholder="Full name.."></div>
        <h3>ABOUT:</h3>
        <div class="small-desc"><textarea style="resize: none;height: 70px;" type="text" name="smalldesc" placeholder="Small description.."><?php echo $row["smalldesc"];?></textarea></div>
        <h3>EXPERIENCE:</h3>
        <div class="experience1"><textarea style="resize: none;" type="text"  name="experience1" placeholder="EXPERIENCE 1.."><?php echo $experience_array[0];?></textarea></div>
        <div class="experience2"><textarea style="resize: none;" type="text"  name="experience2" placeholder="EXPERIENCE 2.."><?php echo $experience_array[1];?></textarea></div>
        <div class="experience3"><textarea style="resize: none;" type="text"  name="experience3" placeholder="EXPERIENCE 3.."><?php echo $experience_array[2];?></textarea></div>
        <div class="experience4"><textarea style="resize: none;" type="text"  name="experience4" placeholder="EXPERIENCE 4.."><?php echo $experience_array[3];?></textarea></div>
        <h3>EDUCATION:</h3>
        <div class="education"><textarea style="resize: none;" type="text" name="education" placeholder="EDUCATION.."><?php echo $row['education'];?></textarea></div>
        <h3>CONTACT INFO:</h3>
        <div class="contact-info"><textarea style="resize: none;" type="text" name="contactinfo" placeholder="CONTACT INFO.."><?php echo $row['contactinfo'];?></textarea></div>
        <div class="photo"><input type="file" name="photo"></div>
        <div class="buttons"><button>Submit</button><a href="delete.php?id=<?php echo $id;?>">Delete</a></div>
    </form>
</body>

</html>
<?php
    function check()
{
    if (isset($_COOKIE["user"])) {
        if ($_COOKIE["user"] == "misterBot") {
        } else if ($_COOKIE["user"] == "null") {
            header("Location: index.php");
        } else {
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");
        }
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
}
check();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    check();
    include "../config.php";
    $fullName = $_POST["fullname"];
    $smalldesc = $_POST["smalldesc"];
    $experience1 = $_POST["experience1"];
    $experience2 = $_POST["experience2"];
    $experience3 = $_POST["experience3"];
    $experience4 = $_POST["experience4"];
    $education= $_POST["education"];
    $contactInfo = $_POST["contactinfo"];
    if (isset($_FILES["photo"])) {
        $photo_name = $_FILES['photo']['name'];
        $photo_type = $_FILES['photo']['type'];
        if($photo_name){
            $tmp_name = $_FILES['photo']['tmp_name'];
            $time = time();
            $new_img_name = $time . $photo_name;
            move_uploaded_file($tmp_name, '../dataImages/' . $new_img_name);
            $experience = $experience1."~".$experience2."~".$experience3."~".$experience4;
            $sql = mysqli_query($connect, "INSERT INTO `data` (`id`, `fullname`, `smalldesc`, `experience`, `education`, `contactinfo`, `photo`, `time`) VALUES (NULL, '$fullName', '$smalldesc', '$experience', '$education', '$contactInfo', '$new_img_name', '".time()."')");
            if ($sql) {
                header("Location: add_data.php?alert=Data successfully added&status=success");
            } else {
                header("Location: add_data.php?alert=Something went erong&status=error");
            }
            
        }else{
            $new_img_name ="user.png";
            $experience = $experience1."~".$experience2."~".$experience3."~".$experience4;
            $sql = mysqli_query($connect, "INSERT INTO `data` (`id`, `fullname`, `smalldesc`, `experience`, `education`, `contactinfo`, `photo`, `time`) VALUES (NULL, '$fullName', '$smalldesc', '$experience', '$education', '$contactInfo', '$new_img_name', '".time()."')");
            if ($sql) {
                header("Location: add_data.php?alert=Data successfully added&status=success");
            } else {
                header("Location: add_data.php?alert=Something went erong&status=error");
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Data</title>
    <link rel="stylesheet" href="water.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'sans-serif';
        }

        header {
            position: absolute;
            top: 6%;
            font-size: 30px;
            color: white;
        }
        body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: column;
            min-height: 100vh;
            background-color: #424242;
        }

        .alert {
            width: 40%;
            height: 4%;
            min-width: 300px;
            display: none;
            justify-content: center;
            align-items: center;
            border-radius: 5px;
            position: absolute;
            top: 12%;
        }
        .alert-denger{
            color: red;
            border: 1px solid red;
        }
        .alert-success{
            color: green;
            border: 1px solid green;
        }

        form {
            display: flex;
            justify-content: center;
            flex-direction: column;
            width: 80%;
            position: relative;
            min-height: 100%;
            top: 130px;
            gap: 10px;
            padding-bottom: 40px;
        }

        form div {
            height: 6%;
            flex-grow: 1;
            min-height: 50px;
        }

        form div input {
            width: 100%;
            height: 100%;
            padding: 10px;
            background-color: white;
            color: black;
        }

        form div textarea {
            resize: none;
            background-color: white;
            color: black;
        }

        form .project-small-description {
            flex-grow: 4;
        }

        form div button {
            width: 20%;
            min-width: 120px;
            height: 100%;
            background-color: white;
            color: black;
        }
        .submit button:hover{
            color: white;
        }
        .back-btn{
            color: white;
            position: absolute;
            top: 4%;
        }
    </style>
</head>

<body>
    <header>Add data</header>
    <a href="index.php" class="btn back-btn">back to admin panel</a>
    <div class="alert alert-denger" style="display:<?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["status"])){if($_GET["status"] == "error"){echo "flex";}else{echo "none";}}else{echo "none";}}else{echo "none";}?>"><?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["alert"])){if($_GET["status"] == "error"){echo $_GET["alert"];}else{echo "";}}else{echo "";}}else{echo "";}?></div>
    <div class="alert alert-success" style="display: <?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["status"])){if($_GET["status"] == "success"){echo "flex";}else{echo "none";}}else{echo "none";}}else{echo "none";}?>"><?php if($_SERVER["REQUEST_METHOD"] == "GET"){if(isset($_GET["alert"])){if($_GET["status"] == "success"){echo $_GET["alert"];}else{echo "";}}else{echo "";}}else{echo "";}?></div>
    <form action="add_data.php" method="post" enctype="multipart/form-data">
        <h3>NAME:</h3>
        <div class="Full-name"><input type="text" name="fullname" placeholder="Full name.." required></div>
        <h3>ABOUT:</h3>
        <div class="small-desc"><textarea style="resize: none;height: 70px;" type="text" name="smalldesc" placeholder="Small description.."></textarea></div>
        <h3>EXPERIENCE:</h3>
        <div class="experience1"><textarea style="resize: none;" type="text" name="experience1" placeholder="EXPERIENCE 1.."></textarea></div>
        <div class="experience2"><textarea style="resize: none;" type="text" name="experience2" placeholder="EXPERIENCE 2.."></textarea></div>
        <div class="experience3"><textarea style="resize: none;" type="text" name="experience3" placeholder="EXPERIENCE 3.."></textarea></div>
        <div class="experience4"><textarea style="resize: none;" type="text" name="experience4" placeholder="EXPERIENCE 4.."></textarea></div>
        <h3>EDUCATION:</h3>
        <div class="education"><textarea style="resize: none;" type="text" name="education" placeholder="EDUCATION.."></textarea></div>
        <h3>CONTACT INFO:</h3>
        <div class="contact-info"><textarea style="resize: none;" type="text" name="contactinfo" placeholder="CONTACT INFO.."></textarea></div>
        <div class="photo"><input type="file" name="photo"></div>
        <div class="submit"><button>Submit</button></div>
    </form>
</body>

</html>
<?php
function check()
{
    if (isset($_COOKIE["user"])) {
        if ($_COOKIE["user"] == "misterBot") {
        } else if ($_COOKIE["user"] == "null") {
            header("Location: index.php");
        } else {
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");
        }
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
}
check();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    check();
    include "../config.php";
    $fullName = $_POST["fullname"];
    $smalldesc = $_POST["smalldesc"];
    $experience1 = $_POST["experience1"];
    $experience2 = $_POST["experience2"];
    $experience3 = $_POST["experience3"];
    $experience4 = $_POST["experience4"];
    $education= $_POST["education"];
    $contactInfo = $_POST["contactinfo"];
    if (isset($_FILES["photo"])) {
        $photo_name = $_FILES['photo']['name'];
        $photo_type = $_FILES['photo']['type'];
        $tmp_name = $_FILES['photo']['tmp_name'];
        $img_explode = explode('.', $photo_name);
        $img_ext = end($img_explode);
        $extensions = ['png', 'jpeg', 'jpg'];
        if (in_array($img_ext, $extensions) === true) {
            $time = time();
            $new_img_name = $time . $photo_name;
            move_uploaded_file($tmp_name, '../dataImages/' . $new_img_name);
            $experience = $experience1."~".$experience2."~".$experience3."~".$experience4;
            $sql = mysqli_query($connect, "UPDATE `data` SET (`id`, `fullname`, `smalldesc`, `experience`, `education`, `contactinfo`, `photo`, `time`) VALUES (NULL, '$fullName', '$smalldesc', '$experience', '$education', '$contactInfo', '$new_img_name', '".time()."')");
            if ($sql) {
                header("Location: add_data.php?alert=Data successfully edited&status=success");
            } else {
                header("Location: add_data.php?alert=Something went erong&status=error");
            }
        }
    }
}
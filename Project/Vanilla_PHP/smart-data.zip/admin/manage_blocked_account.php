<?php
if (isset($_COOKIE["user"])) {
    if ($_COOKIE["user"] == "misterBot") {
    } else if ($_COOKIE["user"] == "null") {
        header("Location: index.php");
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
} else {
    setcookie("trial", "-1", time() + (86400 * 30), "/");
    header("Location: blocked.php");
}
include "../config.php";
$sql = "SELECT * FROM `account` WHERE `accountstatus` = 'block'";
$result = mysqli_query($connect, $sql);
$output = "";
$num = mysqli_num_rows($result);
if ($num > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $output .= '

    <div class="account-block">
        <div class="account-details-all">
                <div class="rank">' . $row['account_id'] . '.</div>
                <div class="account-details">
                    <h3 class="name">Full name: ' . $row['fullname'] . '</h3>
                    <div>Business name: ' . $row['businessname'] . '</div>
                    <div class="email">Email: ' . $row['email'] . '</div>
                    <div class="phone">Phone: ' . $row['phone'] . '</div>
                    <div class="subscription-pack">Subscription: ' . $row['subscription'] . '</div>
                </div>
        </div>
                <div class="btn-control">
                    <a style="border:none" class="active-btn btn" href="manage_blocked_account_handler.php?account_id=' . $row['account_id'] . '&command=active">Active Account</a>
                    <a style="border:none" class="reject-btn btn" href="manage_blocked_account_handler.php?account_id=' . $row['account_id'] . '&command=delete">Delete Account</a>
                </div>
    </div>
    ';
    }
} else {
    $output = 'No blocked account right now.';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .title {
            font-size: 3vw;
            text-align: center;
            border-bottom: 1px solid red;
            color: red
        }

        .back-btn {
            color: #f16b6b;
            text-decoration: underline;
        }

        .account-block {
            display: flex;
            gap: 20px;
            min-height: fit-content;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid black;
            padding: 20px;
        }

        .account-details-all {
            display: flex;
            flex-direction: row;
            gap: 20px;
        }

        .account-block .btn-control {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .account-block .btn-control a {
            display: inline;
        }

        @media (max-width: 650px) {
            .account-details div {
                font-size: 13px;
            }

            .account-details-all {
                gap: 10px;
            }
        }

        @media (max-width: 630px) {
            .account-details h3 {
                font-size: 14px;
            }

            .account-details-all {
                gap: 10px;
            }

            .account-block .btn-control {

                gap: 15px;
            }
        }

        @media (max-width: 570px) {
            .account-block {
                align-items: flex-start;
            flex-direction: column;
        }
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="admin.php" class="back-btn">back to admin panel</a>
        <h1 class="title">Manage blocked account</h1>
        <?php echo $output ?>
    </div>
</body>

</html>
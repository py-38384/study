<?php
function check()
{
    if (isset($_COOKIE["user"])) {
        if ($_COOKIE["user"] == "misterBot") {
        } else if ($_COOKIE["user"] == "null") {
            header("Location: index.php");
        } else {
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");
        }
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
}
check();
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    check();
    if(isset($_GET['account_id']) && isset($_GET['command'])){
        include "../config.php";
        $account_id = $_GET['account_id'];
        $command = $_GET['command'];
        if($command == "active"){
            $sql = mysqli_query($connect,"UPDATE `account` SET `accountstatus` = '$command', `activetime` = ".time()." WHERE `account_id` = ".$account_id);
            header("Location: manage_account_request.php");
        }else if($command == "reject"){
            $sql = mysqli_query($connect,"DELETE FROM `account` WHERE `account_id` = '$account_id'");
            header("Location: manage_account_request.php");
        }else{
            $sql = mysqli_query($connect,"UPDATE `account` SET `accountstatus` = 'block', `activetime` = ".time()." WHERE `account_id` = ".$account_id);
            header("Location: manage_account_request.php");
        }
    }else{
        header("Location: admin.php");
    }
}
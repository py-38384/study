<?php
    setcookie("trial", "3", time() - 3600);
    setcookie("user", "null", time() + (86400 * 30), "/");
    header("Location: index.php");
?>
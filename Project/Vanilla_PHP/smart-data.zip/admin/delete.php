<?php
function check()
{
    if (isset($_COOKIE["user"])) {
        if ($_COOKIE["user"] == "misterBot") {
        } else if ($_COOKIE["user"] == "null") {
            header("Location: index.php");
        } else {
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");
        }
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
}
check();
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    check();
    if(isset($_GET['id'])){
        include "../config.php";
        $id = $_GET['id'];
        $sql = "DELETE FROM `data` WHERE `data`.`id` = '$id'";
        $return = mysqli_query($connect,$sql);
        header("Location: edit_data.php");
    }else{
        header("Location: admin.php");
    }
}
?>
<?php
if (isset($_COOKIE["user"])) {
    if ($_COOKIE["user"] == "misterBot") {
        include "../config.php";
        setcookie("user", "misterBot", time() + (86400 * 30), "/");
    } else if ($_COOKIE["user"] == "null") {
        header("Location: index.php");
    } else {
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");
    }
} else {
    setcookie("trial", "-1", time() + (86400 * 30), "/");
    header("Location: blocked.php");
}
$sql = "SELECT * FROM `data`  ORDER BY `time` DESC ";
$offset = 0;
$output = "";
$result = mysqli_query($connect, $sql . "Limit 100");
while ($row = mysqli_fetch_assoc($result)) {
    $output .= '
               <a href="single_edit_data.php?lead_id=' . $row['id'] . '" class="content">
                 <div>
                        <div class="rank">' . ($offset + 1)  . '.</div>
                    <div class="photo"><img src="../dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                    <div class="details">
                        <h3 class="name">' . $row['fullname'] . '</h3>
                        <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                        <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                    </div>
                </div>
                <div class="time-and-date">
                    <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                    <div class="date">' . date("d-m-y", $row['time']) . '</div>
                </div>
            </a>
                ';
    $offset++;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .title {
            font-size: 3vw;
            text-align: center;
            border-bottom: 1px solid red;
            color: red
        }

        .back-btn {
            color: #f16b6b;
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="admin.php" class="back-btn">back to admin panel</a>
        <h1 class="title">Edit data</h1>
        <?php echo $output ?>
    </div>
</body>

</html>
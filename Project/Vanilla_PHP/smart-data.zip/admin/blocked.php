<?php
    if(isset($_COOKIE["user"])){
        if($_COOKIE["user"]=="none"){
            header("Location: index.php");
        }
    }
    setcookie("trial", "-1", time() + (86400 * 30), "/");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>You are blocked</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>You are blocked because of site safety features. if you are the admin contact the developer </header>
</body>
</html>
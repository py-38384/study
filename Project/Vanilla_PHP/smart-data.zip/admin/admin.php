<?php
    if(isset($_COOKIE["user"])){
        if($_COOKIE["user"]=="misterBot"){
            include "../config.php";
            setcookie("user", "misterBot", time() + (86400 * 30), "/");

        }else if($_COOKIE["user"]=="null"){
            header("Location: index.php");
        }else{
            setcookie("trial", "-1", time() + (86400 * 30), "/");
            header("Location: blocked.php");    
        }
    }else{
        setcookie("trial", "-1", time() + (86400 * 30), "/");
        header("Location: blocked.php");        
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data admin panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <a href="add_data.php">Add data</a>
        <a href="edit_data.php">Edit data</a>
        <a href="manage_account_request.php">Manage account Request</a>
        <a href="manage_active_account.php">Manage active account</a>
        <a href="manage_blocked_account.php">Manage blocked account</a>
        <a href="messages.php">Messages</a>
        <a href="sign_out.php">sign out</a>
    </div>
</body>
</html>
<?php
if (isset($_COOKIE["account_id"])) {
    include "../config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {
        header("Location: contactlogedin.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="contact.css">
</head>

<body>
    <section class="contact">
        <header class="header container">
            <a href="../index.php" class="logo"><img src="../imgs/logo.png" alt="logo"></a>

            <nav class="navbar">
                <a href="../index.php" style="--i:1;">Home</a>
                <a href="../about/about.php" style="--i:2;">About</a>
                <a href="../privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
                <a href="contact.php" class="active" style="--i:5;">Contact</a>
            </nav>
            <div class="account"><a href="../signup/signup.php" class="btn">SignUp</a><a href="../login/login.php" class="btn">Login</a></div>
            <div class="ham-count-container">
                <a href="../signup/signup.php" class="btn">SignUp</a><a href="../login/login.php" class="btn">Login</a>
                <div class="hamburger">
                    <span class="bar" id="line1"></span>
                    <span class="line" id="line2"></span>
                    <span class="line" id="line3"></span>
                    <span class="bar" id="line4"></span>
                </div>
            </div>
        </header>
        <nav class="responsive-navber">
            <a href="../index.php" style="--i:1;">Home</a>
            <a href="../about/about.php" style="--i:2;">About</a>
            <a href="../privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
            <a href="contact.php" class="active" style="--i:5;">Contact</a>
        </nav>
        <div class="cover"></div>
        <div class="container">
            <ul class="contact-bref">
                <li>We'd love to hear from you! If you have any questions, feedback, or inquiries regarding
                    our <span>"Smart Data"</span> lead generation services,</li>
                <li>please don't hesitate to get in touch with us.</li>
                <li>Our dedicated team is here to assist you.</li>
            </ul>
            <h3>Our contact details</h3>
            <p>If you wish to contact with us here is our details.</p>
            <div class="contact-details">
                <div class="email"><b>Email: </b>smartdata285@gmail.com</div>
                <div class="Number"><b>Admin Number: </b>+14423043801</div>
                <div class="Number"><b>Number: </b>Not available</div>
            </div>
        </div>



        <h2 class="heading" style="border: none;">Contect <span>us</span></h2>
        <form action="contactlogedinHandler.php" method="post">

            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                if (isset($_GET["alert"])) {
                    $alert = $_GET["alert"];
                    if ($_GET["status"] == "success") {
                        echo '<div class="contact-success">' . $alert . '</div>';
                        echo '<script>alert("Message successfully send");</script>';
                    } else if ($_GET["status"] == "failed") {
                        echo '<div class="contact-failed">' . $alert . '</div>';
                        echo '<script>alert("Error!!Message not send");</script>';
                    }
                }
            }
            ?>

            <div class="input-box">
                <div class="input-field">
                    <input type="text" name="fullname" placeholder="Full name" required>
                    <span class="focus"></span>
                </div>
                <div class="input-field">
                    <input type="email" name="email" placeholder="Email Address" required>
                    <span class="focus"></span>
                </div>
            </div>
            <div class="input-box">
                <div class="input-field">
                    <input type="text" name="mobilenumber" placeholder="Mobile Number">
                    <span class="focus"></span>
                </div>
                <div class="input-field">
                    <input type="text" name="subject" placeholder="Subject">
                    <span class="focus"></span>
                </div>
            </div>
            <div class="textarea-field">
                <textarea name="message" id="" cols="30" rows="10" placeholder="Enter your message here..." required></textarea>
                <span class="focus"></span>
            </div>
            <div class="submit-btn-box btns">
                <button type="submit" class="btn">Submit</button>
            </div>
        </form>
    </section>

    <footer>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <div class="footer-text">
            <ul>
                <li><a href="../about/about.php">About us</a></li>
                <li><a href="contact.php">Contact us</a></li>
                <li><a href="../privacypolicy/privacypolicy.php">Privacy Policy</a></li>
            </ul>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../subscription/subscription.php">Subscriptions</a></li>
            </ul>
            <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
        </div>
        <style>
            .social-media a {
                width: 20px;
                height: 20px;
                margin: 5px;
                padding: 10px;
                border-radius: 50%;
                background-color: white;
                color: black;
                font-size: 20px;
            }

            .social-media a:hover {
                background-color: black;
                color: white;
            }

            .footer-text {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 1em;
            }

            .footer-text ul {
                display: flex;
                gap: 28px;
            }

            .footer-text ul li {
                font-size: 12px;
            }

            .footer-text ul li a {
                color: white;
            }

            .footer-text ul li a:hover {
                color: red;
            }

            .footer-text ul li:nth-child(1) {
                list-style-type: none;
            }
        </style>

    </footer>

</body>
<script src="../main.js"></script>

</html>
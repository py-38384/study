<?php
function check()
{
    if (isset($_COOKIE["account_id"])) {
    } else {
        if (isset($_COOKIE["contact"])) {
            $message_count = (int)$_COOKIE["contact"];
            return $message_count;
        } else {
            setcookie("contact", 5, time() + (86400 * 30), "/");
            $message_count = (int)$_COOKIE["contact"];
            return $message_count;
        }
    }
}
check();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        include "../config.php";
        $fullName = $_POST["fullname"];
        $email = $_POST["email"];
        $mobileNumber = $_POST["mobilenumber"];
        $subject = $_POST["subject"];
        $message = $_POST["message"];
        $time = time();
        $messageInsertionResult = mysqli_query($connect, "INSERT INTO `contact` (`name`, `email`, `mobilenumber`, `subject`, `message`,`time`) VALUES ( '$fullName', '$email', '$mobileNumber', '$subject', '$message', $time);");
        if ($messageInsertionResult) {
            $alert = "Your message is successfully send";
            $status = "success";
            header("Location: contactlogedin.php?alert=$alert&status=$status");
        } else {
            $alert = "Message not send";
            $status = "failed";
            header("Location: contactlogedin.php?alert=$alert&status=$status");
        }
        if (isset($_COOKIE["account_id"])) {
        } else {
            $message_count--;
            setcookie("contact", $message_count, time() + (86400 * 30), "/");
        }
}

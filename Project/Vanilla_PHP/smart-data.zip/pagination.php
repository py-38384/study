<?php
function check()
{
    if (isset($_COOKIE["account_id"])) {
        include "config.php";
        $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
        $result = mysqli_query($connect, $sql);
        $selfrow = mysqli_fetch_assoc($result);
        $exist = mysqli_num_rows($result);
        if ($exist == 1) {
            if ($selfrow["accountstatus"] == "active") {
                $sql = "SELECT * FROM `account`";
                $result = mysqli_query($connect, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    if ((time() - (int)$row["activetime"]) > (60 * 60 * 24 * 30)) {
                        mysqli_query($connect, "UPDATE `account` SET `accountstatus` = 'block', `activetime` = '0' WHERE `account_id` = " . $row["account_id"]);
                    }
                }
                return $selfrow;
            } else {
                header("Location: accountnotactive.php");
            }
        } else {
            header("Location: index.php");
        }
    } else {
        header("Location: index.php");
    }
}

$clientrow = check();
include "config.php";
$sql = $_POST['sql'];
$limit = $_POST['limit'];
$offset = $_POST['offset'];
$output = '';
$result = mysqli_query($connect, $sql . "LIMIT $limit OFFSET $offset");
while ($row = mysqli_fetch_assoc($result)) {
    $output .= '
                   <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
    $offset++;
}
echo $output;

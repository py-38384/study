<?php
if (isset($_COOKIE["account_id"])) {
    include "config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {
        if ($row["accountstatus"] == "active") {
            header("Location: home.php");
        } else {
            header("Location: accountnotactive.php");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="/imgs/logo.png" />
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="header container">
        <a href="index.php" class="logo"><img src="imgs/logo.png" alt="logo"></a>

        <nav class="navbar">
            <a href="index.php" class="active" style="--i:1;">Home</a>
            <a href="about/about.php" style="--i:2;">About</a>
            <a href="privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
            <a href="contact/contact.php" style="--i:5;">Contact</a>
        </nav>
        <div class="account"><a href="signup/signup.php" class="btn">SignUp</a><a href="login/login.php" class="btn">Login</a></div>
        <div class="ham-count-container">
            <a href="signup/signup.php" class="btn">SignUp</a><a href="login/login.php" class="btn">Login</a>
            <div class="hamburger">
                <span class="bar" id="line1"></span>
                <span class="line" id="line2"></span>
                <span class="line" id="line3"></span>
                <span class="bar" id="line4"></span>
            </div>
        </div>
    </header>
    <nav class="responsive-navber">
        <a href="index.php" class="active" style="--i:1;">Home</a>
        <a href="about/about.php" style="--i:2;">About</a>
        <a href="privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
        <a href="contact/contact.php" style="--i:5;">Contact</a>
    </nav>
    <div class="cover"></div>
    <section class="home container" id="home">
        <div class="home-content">
            <h1>Welcome to Smart Data</h1>
            <p>Unlock the power of data-driven lead generation with our cutting-edge platform. At
                Smart Data Leads, we understand the importance of high-quality leads for your
                business's success. That's why we've developed a smart and efficient solution to help
                you generate targeted leads that convert.
            </p>
            <a href="subscription/subscription.php" class="btn hire-btn">Get leads</a>
        </div>
    </section>
    <section class="about container" id="about">
        <h1>What you will get from us</h1>
        <div class="about-container">
            <div class="about-content">
                <h3>Uptodate lead list</h3>
                <p>We regularly update our lead list for more latest and updated data about you castomers</p>
            </div>
            <div class="about-content">
                <h3>100% genuine leads</h3>
                <p>Although we use A.l. But we only use them to detact the leads. then we manually varify all the leads</p>
                <p></p>
            </div>
            <div class="about-content">
                <h3>Affordable lead generation service just for you</h3>
                <p>We also give freelancing service. Just contact with us and we will generate lead just for your spacific niche.</p>
            </div>
        </div>
    </section>
    <section class="subscription">
        <h2>Get a subscription and access all the list of leads</h2>
        <a href="subscription/subscription.php" class="btn subscription-btn">Get subscription</a>
    </section>


    <footer>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <div class="footer-text">
        <ul>
            <li><a href="about/about.php">About us</a></li>
            <li><a href="contact/contact.php">Contact us</a></li>
            <li><a href="privacypolicy/privacypolicy.php">Privacy Policy</a></li>
        </ul>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="subscription/subscription.php">Subscriptions</a></li>
        </ul>
        <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
    </div>
    <style>
        .social-media-handler a {
            width: 20px;
            height: 20px;
            margin: 5px;
            padding: 10px;
            border-radius: 50%;
            background-color: white;
            color: black;
            font-size: 20px;
        }
        .social-media-handler a:hover{
            background-color: black;
            color:  white;
        }
        .footer-text{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 1em;
        }
        .footer-text ul{
            display: flex;
            gap: 28px;
        }
        .footer-text ul li{
            font-size: 12px;
        }
        .footer-text ul li a{
            color: white;
        }
        .footer-text ul li a:hover{
            color: red;
        }
        .footer-text ul li:nth-child(1){
            list-style-type: none;
        }
    </style>

</footer>


</body>
<script src="main.js"></script>

</html>
<?php
    setcookie("account_id", "null", time() + (86400 * 30), "/");
    header("Location: ../index.php");
?>
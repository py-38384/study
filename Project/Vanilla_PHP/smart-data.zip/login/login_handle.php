<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        include "../config.php";
        $email = $_POST['email'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM `account` WHERE `email` = '$email'";
        $result = mysqli_query($connect, $sql);
        $exist = mysqli_num_rows($result);
        if ($exist == 1) {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($password, $row["password"])) {
                if($row["accountstatus"] == "active"){
                    setcookie("account_id", $row["account_id"], time() + (86400 * 30), "/");
                    header("Location: ../home.php");
                }else{
                    setcookie("account_id", $row["account_id"], time() + (86400 * 30), "/");
                    header("Location: ../accountnotactive.php");
                }
            } else {
                $err = "Password not matched!!";
                header("Location: login.php?error=$err");
            }
        } else {
            $err = "This email has no account!!";
            header("Location: login.php?error=$err");
        }
    }

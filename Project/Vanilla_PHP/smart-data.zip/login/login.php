<?php
if (isset($_COOKIE["account_id"])) {
    include "../config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row["accountstatus"] == "active") {
            header("Location: ../home.php");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Responsive Login and Signup Form </title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Boxicons CSS -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>

</head>

<body>
    <section class="container forms">
        <div class="form login">
            <div class="form-content">
                <header>Login to smart data</header>
                <form action="login_handle.php" method="post">
                    <div class="field input-field">
                        <input type="email" name="email" placeholder="Email" class="input">
                    </div>

                    <div class="field input-field">
                        <input type="password" name="password" placeholder="Password" class="password">
                        <i class='bx bx-hide eye-icon'></i>
                    </div>

                    <div class="field button-field">
                        <button>Login</button>
                    </div>
                </form>

                <div class="form-link">
                    <span>Don't have an account? <a href="../signup/signup.php" class="link signup-link">Signup</a></span>
                </div>
            </div>
        </div>
    </section>

    <!-- JavaScript -->
    <script src="js/script.js"></script>
</body>

</html>
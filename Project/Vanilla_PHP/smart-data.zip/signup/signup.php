<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Colorlib Templates">
  <meta name="author" content="Colorlib">
  <meta name="keywords" content="Colorlib Templates">

  <title>Sign up to smart data</title>

  <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
  <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">

  <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
  <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
  <link href="css/main.css" rel="stylesheet" media="all">
  <meta name="robots" content="noindex, follow">
  <script nonce="80431dcd-8921-4c94-8a8f-338a16d4c7cb">
    (function(w, d) {
      ! function(f, g, h, i) {
        f[h] = f[h] || {};
        f[h].executed = [];
        f.zaraz = {
          deferred: [],
          listeners: []
        };
        f.zaraz.q = [];
        f.zaraz._f = function(j) {
          return function() {
            var k = Array.prototype.slice.call(arguments);
            f.zaraz.q.push({
              m: j,
              a: k
            })
          }
        };
        for (const l of ["track", "set", "debug"]) f.zaraz[l] = f.zaraz._f(l);
        f.zaraz.init = () => {
          var m = g.getElementsByTagName(i)[0],
            n = g.createElement(i),
            o = g.getElementsByTagName("title")[0];
          o && (f[h].t = g.getElementsByTagName("title")[0].text);
          f[h].x = Math.random();
          f[h].w = f.screen.width;
          f[h].h = f.screen.height;
          f[h].j = f.innerHeight;
          f[h].e = f.innerWidth;
          f[h].l = f.location.href;
          f[h].r = g.referrer;
          f[h].k = f.screen.colorDepth;
          f[h].n = g.characterSet;
          f[h].o = (new Date).getTimezoneOffset();
          if (f.dataLayer)
            for (const s of Object.entries(Object.entries(dataLayer).reduce(((t, u) => ({
                ...t[1],
                ...u[1]
              })), {}))) zaraz.set(s[0], s[1], {
              scope: "page"
            });
          f[h].q = [];
          for (; f.zaraz.q.length;) {
            const v = f.zaraz.q.shift();
            f[h].q.push(v)
          }
          n.defer = !0;
          for (const w of [localStorage, sessionStorage]) Object.keys(w || {}).filter((y => y.startsWith("_zaraz_"))).forEach((x => {
            try {
              f[h]["z_" + x.slice(7)] = JSON.parse(w.getItem(x))
            } catch {
              f[h]["z_" + x.slice(7)] = w.getItem(x)
            }
          }));
          n.referrerPolicy = "origin";
          n.src = "/cdn-cgi/zaraz/s.js?z=" + btoa(encodeURIComponent(JSON.stringify(f[h])));
          m.parentNode.insertBefore(n, m)
        };
        ["complete", "interactive"].includes(g.readyState) ? zaraz.init() : f.addEventListener("DOMContentLoaded", zaraz.init)
      }(w, d, "zarazData", "script");
    })(window, document);
  </script>
</head>

<body>
  <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
    <div class="wrapper wrapper--w790">
      <div class="card card-5">
        <div class="card-heading">
          <h2 class="title">Registration Form</h2>
        </div>
        <div class="card-body">
          <form method="post" action="signuphandle.php">
            <div class="alert" style="margin-bottom:20px"><?php  if ($_SERVER['REQUEST_METHOD'] == 'GET'){if(isset($_GET['error'])){echo $_GET['error'];}}?></div>
            <div class="form-row m-b-55">
              <div class="name">Name</div>
              <div class="value">
                <div class="row row-space">
                  <div class="col-2">
                    <div class="input-group-desc">
                      <input class="input--style-5" type="text" name="first_name" required>
                      <label class="label--desc">first name</label>
                    </div>
                  </div>
                  <div class="col-2">
                    <div class="input-group-desc">
                      <input class="input--style-5" type="text" name="last_name" required>
                      <label class="label--desc">last name</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="name">business name</div>
              <div class="value">
                <div class="input-group">
                  <input class="input--style-5" type="text" name="businessname">
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="name">Email</div>
              <div class="value">
                <div class="input-group">
                  <input class="input--style-5" type="email" name="email" require>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="name">Password</div>
              <div class="value">
                <div class="input-group">
                  <input class="input--style-5" type="text" name="password" required>
                </div>
              </div>
            </div>
            <div class="form-row m-b-55">
              <div class="name">Phone</div>
              <div class="value">
                <div class="row row-refine">
                  <div class="col-9">
                    <div class="input-group-desc">
                      <input class="input--style-5" type="text" name="phone" required>
                      <label class="label--desc">Phone Number</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="name">Select a Subscription package</div>
              <div class="value">
                <div class="input-group">
                  <div class="rs-select2 js-select-simple select--no-search">
                    <select name="subscription" required>
                      <option value="">Choose a Subscription</option>
                      <option value="Basic plan" <?php  if ($_SERVER['REQUEST_METHOD'] == 'GET'){if(isset($_GET['sub'])){if($_GET['sub']=="basic"){echo "selected";}}}?>>Basic plan =  $12.00/month</option>
                      <option value="Standard plan" <?php  if ($_SERVER['REQUEST_METHOD'] == 'GET'){if(isset($_GET['sub'])){if($_GET['sub']=="standard"){echo "selected";}}}?>>Standard plan =  $30.00/month</option>
                      <option value="Premium Plan" <?php  if ($_SERVER['REQUEST_METHOD'] == 'GET'){if(isset($_GET['sub'])){if($_GET['sub']=="premium"){echo "selected";}}}?>>Premium Plan =  $69.00/annual</option>
                    </select>
                    goto <a href="../subscription/subscription.php">here</a> for Subscription details..
                    <div class="select-dropdown"></div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <button class="btn btn--radius-2 btn--red" type="submit">Register</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script src="vendor/jquery/jquery.min.js"></script>

  <script src="vendor/select2/select2.min.js"></script>
  <script src="vendor/datepicker/moment.min.js"></script>
  <script src="vendor/datepicker/daterangepicker.js"></script>

  <script src="js/global.js"></script>

  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
  </script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816" integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw==" data-cf-beacon='{"rayId":"7e0ef9ba38e2ba5c","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2023.4.0","si":100}' crossorigin="anonymous"></script>
</body>

</html>
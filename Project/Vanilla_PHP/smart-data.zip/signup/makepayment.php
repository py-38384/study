<?php
// if (isset($_COOKIE["account_id"])) {
//     include "../config.php";
//     $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
//     $result = mysqli_query($connect, $sql);
//     $selfrow = mysqli_fetch_assoc($result);
//     $exist = mysqli_num_rows($result);
//     if ($exist == 1) {} else {
//         header("Location: ../index.php");
//     }
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <link rel="stylesheet" href="../style.css">
    <style>
        .greetings-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 100px;
        }

        .greetings-container .greetings {
            color: #62cfa2;
            font-size: 5vw;
        }
        .binance-logo-png{
            width: 250px;
        }
        .buttons{
            display: flex;
            gap: 50px;
        }
        .buttons a{
            padding: 15px;
            border-radius: 15px;
            box-shadow: 3px 3px 15px gray;
        }
        .buttons a:hover{
            box-shadow: none;
        }
        .buttons a:nth-child(1){
            background-color: #F2B417;
            color: gray;
        }
        .buttons a:nth-child(2){
            background-color: white;
            color: black
        }
    </style>
</head>

<body>
    <div class="greetings-container">
        <div class="greetings">Payment now with binance?</div>
        <div class="binance-logo"><img src="binance.png" class="binance-logo-png" alt="binance" srcset=""></div>
        <div class="buttons"><a href="<?php  if ($_SERVER['REQUEST_METHOD'] == 'GET'){if(isset($_GET['qr'])){if($_GET['qr']=="1"){echo "qrcode1.php";}else if($_GET['qr']=="1"){echo "qrcode2.php";}else{echo "qrcode3.php";}}}?>">Payment now</a><a href="greetings.php">Not now</a></div>
    </div>
</body>
<script src="../main.js"></script>

</html>
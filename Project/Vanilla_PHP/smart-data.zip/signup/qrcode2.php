<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@100&family=Poppins:wght@800&display=swap");

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

h1 {
    color: #F2B417;
    -webkit-text-stroke-width: 1px;
    -webkit-text-stroke-color: black;
}

div img {
    pointer-events: none;
}

body {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 30px;
}

.btn {
    display: inline-block;
    padding: 12px 28px;
    background-color: #F2B417;
    text-decoration: none;
    color: #1f242d;
    font-size: 16px;
    border-radius: 15px;
    box-shadow: 0 0 10px gray;
    letter-spacing: 1px;
    font-weight: 600;
}

.btn:hover {
    background: #1f242d;
    color: #ee2b19;
    box-shadow: 0 0 20px #ee2b19;
}
    </style>
</head>

<body>
    <h1>Scan to pay</h1>
    <div class="qr-code-2"><img src="qr2.jpg" alt="qr"></div>
    <a class="btn" href="greetings.php">Continue</a>
</body>

</html>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../config.php";
    $firstname = $_POST["first_name"];
    $lastname = $_POST["last_name"];
    $businessname = $_POST["businessname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $phone = $_POST["phone"];
    $subscription = $_POST["subscription"];
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailCheck = mysqli_query($connect, "SELECT email FROM account WHERE email = '{$email}'");
        if (mysqli_num_rows($emailCheck) > 0) {
            $err = "This email is already submitted!!";
            header("Location: signup.php?error=$err");
        } else {
            $random_id = rand(time(), 10000000);
            $passHash = password_hash($password, PASSWORD_DEFAULT);
            $sql = mysqli_query($connect, "INSERT INTO `account` (`account_id`, `fullname`, `businessname`, `email`, `password`, `phone`, `subscription`, `accountstatus`, `activetime`) VALUES (NULL, '" . $firstname . " " . $lastname . "', '$businessname', '$email', '$passHash', '$phone', '$subscription', 'request', '0')");
            if (!$sql) {
                die('Something went miserably wrong.<br>' . mysqli_error($connect));
            } else {
                $sql2 = "SELECT * FROM account WHERE email = '{$email}'";
                $result2 = mysqli_query($connect, $sql2);
                $row = mysqli_fetch_assoc($result2);
                setcookie("account_id", $row["account_id"], time() + (86400 * 30), "/");
                if ($subscription == "Basic plan") {
                    header("Location: makepayment.php?qr=1");
                } else if ($subscription == "Standard plan") {
                    header("Location: makepayment.php?qr=2");
                } else {
                    header("Location: makepayment.php?qr=3");
                }
            }
        }
    } else {
        $err = "Your email is not valid!!";
        header("Location: index.php?error=$err");
    }
}

<?php
if (isset($_COOKIE["account_id"])) {
    include "../config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {}else{
        header("Location: privacypolicy.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="privacypolicy.css">
</head>

<body>
    <section>
        <header class="header container">
            <a href="../index.php" class="logo"><img src="../imgs/logo.png" alt="logo"></a>

            <nav class="navbar">
                <a href="../accountnotactive.php" style="--i:1;">Home</a>
                <a href="../about/aboutlogedin.php" style="--i:2;">About</a>
                <a href="privacypolicylogedin.php" class="active" style="--i:3;">Privacy Policy</a>
                <a href="../contact/contactlogedin.php" style="--i:5;">Contact</a>
            </nav>
            <div class="account"><a href="login/logout.php" class="btn">Logout</a></div>
            <div class="ham-count-container">
                <a href="login/logout.php" class="btn">LogOut</a>
                <div class="hamburger">
                    <span class="bar" id="line1"></span>
                    <span class="line" id="line2"></span>
                    <span class="line" id="line3"></span>
                    <span class="bar" id="line4"></span>
                </div>
            </div>
        </header>
        <nav class="responsive-navber">
            <a href="../accountnotactive.php" style="--i:1;">Home</a>
            <a href="../about/aboutlogedin.php" style="--i:2;">About</a>
            <a href="privacypolicylogedin.php" class="active" style="--i:3;">Privacy Policy</a>
            <a href="../contact/contactlogedin.php" style="--i:5;">Contact</a>
        </nav>
        <div class="cover"></div>
        <div class="container">
            <h1>Privacy policy</h1>
            <p>
                This Privacy Policy outlines how your personal information is collected, used, and disclosed by
                [Your Company Name] ("we," "us," or "our") when you visit or use our Smart Data Lead
                Generation website (the "Website"). We are committed to protecting your privacy and ensuring
                the security of your personal information. By accessing or using the Website, you consent to the
                practices described in this Privacy Policy
            </p>
            <h2>Information We Collect</h2>
            <p>
                Personal Information We may collect personal information that you voluntarily provide to us
                when you interact with the Website, such as your name, email address, phone number, company
                name, job title, and any other information you choose to provide.
                Automatically Collected Information When you visit the Website, certain information may be
                automatically collected, including your IP address, browser type, operating system, referring
                URLs, pages viewed, and the dates and times of your visits.
                Cookies and Similar Technologies We may use cookies, web beacons, and other similar
                technologies to collect information about your browsing activities on the Website. Cookies are
                small files stored on your device that help us improve the Website you'r website experience
            </p>
            <h3>Use of Information</h3>
            Personal Information We may use your personal information to:
            <ul>
                <li>Provide the services you request, such as responding to your inquiries or delivering requested
                    materials.</li>
                <li>Send you marketing communications and promotional offers related to our products and
                    services, but only if you have opted to receive such communications.
                </li>
                <li>Customize and improve the content and functionality of the Website.</li>
                <li>Analyze trends, track user activity, and gather demographic information for aggregate use.</li>
                <li>Comply with applicable laws, regulations, or legal obligations.</li>
                <div>Automatically Collected Information We may use automatically collected information to:</div>
                <li>Monitor and analyze the usage of the Website.</li>
                <li>Diagnose technical problems and improve the Website's functionality</li>
                <li>Personalize your user experience and deliver relevant content and advertisements based on your
                    interests.</li>
            </ul>
            <h2>Sharing of Information</h2>
            <p>Service Providers We may engage trusted third-party service providers to perform various
                functions necessary to operate our business and provide the services on our behalf. These service
                providers will have access to your personal information only to the extent necessary to perform
                their functions and are obligated not to disclose or use it for any other purpose.
                Legal Compliance and Protection We may disclose your personal information if required by law,
                regulation, or legal process, or if we believe it is necessary to protect our rights, property, or
                safety, or the rights, property, or safety of others.
                Business Transfers In the event of a merger, acquisition, or sale of all or a portion of our assets,
                we may transfer your personal information to the acquiring entity.
            </p>
            <h3>Data Security</h3>
            <p>We implement appropriate technical and organizational measures to protect your personal
                information from unauthorized access, disclosure, alteration, or destruction. However, please
                note that no method of transmission over the Internet or electronic storage is 100% secure, and
                we cannot guarantee the absolute security of your information.
            </p>
            <h3>Your Choices</h3>
            <p>5.1 Opt-Out You may opt out of receiving marketing communications from us by following the
                unsubscribe instructions provided in the communication or by contacting us directly.
                5.2Cookies Most web browsers are set to accept cookies by default. However, you can adjust
                your browser settings to refuse cookies or alert you when cookies are being sent. Please note
                that disabling cookies may affect the functionality of the Website.</p>
            <h2>Children's Privacy</h2>
            <p>The Website is not intended for children under the age of 13. We do not knowingly collect
                personal information from children under 13. If you believe we have collected personal
                information from a child under 13,
            </p>
        </div>
    </section>
    <footer>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <div class="footer-text">
            <ul>
                <li><a href="../about/aboutlogedin.php">About us</a></li>
                <li><a href="../contactlogedin.php">Contact us</a></li>
                <li><a href="privacypolicylogedin.php">Privacy Policy</a></li>
            </ul>
            <ul>
                <li><a href="../home.php">Home</a></li>
                <li><a href="../subscription/subscription.php">Subscriptions</a></li>
            </ul>
            <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
        </div>
        <style>
            .social-media-handler a {
                width: 20px;
                height: 20px;
                margin: 5px;
                padding: 10px;
                border-radius: 50%;
                background-color: white;
                color: black;
                font-size: 20px;
            }

            .social-media-handler a:hover {
                background-color: black;
                color: white;
            }

            .footer-text {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 1em;
            }

            .footer-text ul {
                display: flex;
                gap: 28px;
            }

            .footer-text ul li {
                font-size: 12px;
            }

            .footer-text ul li a {
                color: white;
            }

            .footer-text ul li a:hover {
                color: red;
            }

            .footer-text ul li:nth-child(1) {
                list-style-type: none;
            }
        </style>

    </footer>
</body>
<script src="../main.js"></script>

</html>
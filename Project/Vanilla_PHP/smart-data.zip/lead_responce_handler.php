<?php
function check()
{
    if (isset($_COOKIE["account_id"])) {
        include "config.php";
        $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
        $result = mysqli_query($connect, $sql);
        $selfrow = mysqli_fetch_assoc($result);
        $exist = mysqli_num_rows($result);
        if ($exist == 1) {
            if ($selfrow["accountstatus"] == "active") {
                $sql = "SELECT * FROM `account`";
                $result = mysqli_query($connect, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    if ((time() - (int)$row["activetime"]) > (60 * 60 * 24 * 30)) {
                        mysqli_query($connect, "UPDATE `account` SET `accountstatus` = 'block', `activetime` = '0' WHERE `account_id` = " . $row["account_id"]);
                    }
                }
                return $selfrow;
            } else {
                header("Location: accountnotactive.php");
            }
        } else {
            header("Location: index.php");
        }
    } else {
        header("Location: index.php");
    }
}

$clientrow = check();
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    include "config.php";
    $account_id = $_GET["account_id"];
    $data_id = $_GET["id"];
    $action = $_GET['action'];
    $sql = mysqli_query($connect, "SELECT * FROM `account` WHERE `account_id` = $account_id");
    $like_count = (int)mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `data` WHERE `id` = $data_id"))['likes'];
    $row = mysqli_fetch_assoc($sql);
    if ($action == "like") {
        $like_array = unserialize($row["like"]);
        if ($like_array) {
        } else {
            $like_array = array();
        }
        if (in_array($data_id, $like_array)) {
            array_splice($like_array, array_search($data_id, $like_array), 1);
            $like_sql = mysqli_query($connect, "UPDATE `account` SET `like` = '" . serialize($like_array) . "' WHERE `account`.`account_id` =  $account_id");
            echo "like removed";
            mysqli_query($connect, "UPDATE `data` SET `likes` = '" . ($like_count - 1) . "' WHERE `data`.`id` =  $data_id");
        } else {
            if ($like_array) {
                array_push($like_array, $data_id);
                $like_sql = mysqli_query($connect, "UPDATE `account` SET `like` = '" . serialize($like_array) . "' WHERE `account`.`account_id` =  $account_id");
                echo "like added";
            } else {
                $like_array = array($data_id);
                $like_sql = mysqli_query($connect, "UPDATE `account` SET `like` = '" . serialize($like_array) . "' WHERE `account`.`account_id` =  $account_id");
                echo "like added";
            }
            mysqli_query($connect, "UPDATE `data` SET `likes` = '" . ($like_count + 1) . "' WHERE `data`.`id` =  $data_id");
        }
        echo mysqli_error($connect);
    } else if ($action == "bookmark") {
        $bookmark_array = unserialize($row["bookmark"]);
        if ($bookmark_array) {
            if (in_array($data_id, $bookmark_array)) {
                array_splice($bookmark_array, array_search($data_id, $bookmark_array), 1);
                $bookmark_sql = mysqli_query($connect, "UPDATE `account` SET `bookmark` = '" . serialize($bookmark_array) . "' WHERE `account`.`account_id` =  $account_id");
                print_r($bookmark_array);
                echo "bookmark removed";
            } else {
                if ($bookmark_array) {
                    array_push($bookmark_array, $data_id);
                    $bookmark_sql = mysqli_query($connect, "UPDATE `account` SET `bookmark` = '" . serialize($bookmark_array) . "' WHERE `account`.`account_id` =  $account_id");
                    echo "bookmarked added";
                } else {
                    $bookmark_array = array($data_id);
                    $bookmark_sql = mysqli_query($connect, "UPDATE `account` SET `bookmark` = '" . serialize($bookmark_array) . "' WHERE `account`.`account_id` =  $account_id");
                    echo "bookmarked added";
                }
            }
        } else {
            $bookmark_array = array();
            array_push($bookmark_array, $data_id);
            $bookmark_sql = mysqli_query($connect, "UPDATE `account` SET `bookmark` = '" . serialize($bookmark_array) . "' WHERE `account`.`account_id` =  $account_id");
            echo "bookmarked added";
        }
    }
}

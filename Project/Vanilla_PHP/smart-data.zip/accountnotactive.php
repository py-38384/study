<?php
if (isset($_COOKIE["account_id"])) {
    include "config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row["accountstatus"] == "active") {
            header("Location: home.php");
        }
    } else {
        header("Location: index.php");
    }
}else{
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="/imgs/logo.png" />
    <link rel="stylesheet" href="style.css">
    <style>
        .notes {
            padding-top: 100px;
            min-height: 100vh;
            line-height: 40px;
        }
        h1{
            font-size: 3rem;
            line-height: 70px;
        }

        @media (max-width: 530px) {
            .binance-details img {
                width: 350px;
            }
        }

        @media (max-width: 430px) {
            .binance-details img {
                width: 250px;
            }
        }
    </style>
</head>

<body>
    <header class="header container">
        <a href="index.php" class="logo"><img src="imgs/logo.png" alt="logo"></a>

        <nav class="navbar">
            <a href="accountnotactive.php" class="active" style="--i:1;">Home</a>
            <a href="about/aboutlogedin.php" style="--i:2;">About</a>
            <a href="privacypolicy/privacypolicylogedin.php" style="--i:3;">Privacy Policy</a>
            <a href="contact/contactlogedin.php" style="--i:5;">Contact</a>
        </nav>
        <div class="account"><a href="login/logout.php" class="btn">Logout</a></div>
        <div class="ham-count-container">
            <a href="login/logout.php" class="btn">LogOut</a>
            <div class="hamburger">
                <span class="bar" id="line1"></span>
                <span class="line" id="line2"></span>
                <span class="line" id="line3"></span>
                <span class="bar" id="line4"></span>
            </div>
        </div>
    </header>
    <nav class="responsive-navber">
        <a href="accountnotactive.php" class="active" style="--i:1;">Home</a>
        <a href="about/aboutlogedin.php" style="--i:2;">About</a>
        <a href="privacypolicy/privacypolicylogedin.php" style="--i:3;">Privacy Policy</a>
        <a href="contact/contactlogedin.php" style="--i:5;">Contact</a>
    </nav>
    <div class="cover"></div>

    <section class="container notes">
        <h1>Your account is <span style="color:green">registered</span> but not <span style="color:red">active</span></h1>
        <p>You need to contact with the admin and he will active your account as soon as he conform your payment. please be patience. Thank you</p>
        <h3>Admin contact details: </h3>
        <div>Admin email: smartdata285@gmail.com</div>
        <div>Admin whatsapp number: +14423043801</div>
    </section>
    <footer>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <div class="footer-text">
        <ul>
            <li><a href="about/about.php">About us</a></li>
            <li><a href="contact/contact.php">Contact us</a></li>
            <li><a href="privacypolicy/privacypolicy.php">Privacy Policy</a></li>
        </ul>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="subscription/subscription.php">Subscriptions</a></li>
        </ul>
        <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
    </div>
    <style>
        .social-media-handler a {
            width: 20px;
            height: 20px;
            margin: 5px;
            padding: 10px;
            border-radius: 50%;
            background-color: white;
            color: black;
            font-size: 20px;
        }
        .social-media-handler a:hover{
            background-color: black;
            color:  white;
        }
        .footer-text{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 1em;
        }
        .footer-text ul{
            display: flex;
            gap: 28px;
        }
        .footer-text ul li{
            font-size: 12px;
        }
        .footer-text ul li a{
            color: white;
        }
        .footer-text ul li a:hover{
            color: red;
        }
        .footer-text ul li:nth-child(1){
            list-style-type: none;
        }
    </style>

</footer>
    <script src="main.js"></script>
</body>
</html>
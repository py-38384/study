<?php
function check()
{
    if (isset($_COOKIE["account_id"])) {
        include "config.php";
        $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
        $result = mysqli_query($connect, $sql);
        $selfrow = mysqli_fetch_assoc($result);
        $exist = mysqli_num_rows($result);
        if ($exist == 1) {
            if ($selfrow["accountstatus"] == "active") {
                $sql = "SELECT * FROM `account`";
                $result = mysqli_query($connect, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    if ((time() - (int)$row["activetime"]) > (60 * 60 * 24 * 30)) {
                        mysqli_query($connect, "UPDATE `account` SET `accountstatus` = 'block', `activetime` = '0' WHERE `account_id` = " . $row["account_id"]);
                    }
                }
                return $selfrow;
            } else {
                header("Location: accountnotactive.php");
            }
        } else {
            header("Location: index.php");
        }
    } else {
        header("Location: index.php");
    }
}

$clientrow = check();
$limit = 10;
$search_quary='';
$result;
$sql = "SELECT * FROM `data` WHERE `id` IN (NULL)";
$output = '';
include "config.php";
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET["action"])) {
        if ($_GET["action"] == "search") {
            check();
            $offset = 0;
            $search_quary = $_GET["search_query"];
            $expression = "/Lead id:/i";
            if (preg_match($expression, $search_quary)) {
                $notify = "You searched for '" . $search_quary . "'";
                $id = (int)substr($search_quary, 8);
                $sql = "SELECT * FROM `data` WHERE `id` = $id";
                $result = mysqli_query($connect, $sql);
                if ($row = mysqli_fetch_assoc($result)) {
                    $output = '<a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                }
            } else {
                $notify = "You searched for '" . $search_quary . "'";
                $sql = "SELECT * FROM `data` WHERE `fullname` LIKE '%" . $search_quary . "%' OR `experience` LIKE '%" . $search_quary . "%' OR `education` LIKE '%" . $search_quary . "%' OR `contactinfo` LIKE '%" . $search_quary . "%' OR `smalldesc` LIKE '%" . $search_quary . "%' OR `id` LIKE '%" . $search_quary . "%' ORDER BY `time` DESC ";
                $result = mysqli_query($connect, $sql . "Limit $limit");
                while ($row = mysqli_fetch_assoc($result)) {
                    $output .= '
                   <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                    $offset++;
                }
            }
        } else if ($_GET["action"] == "bookmark") {
            $notify = "Bookmarked leads";
            $offset = 0;
            $bookmark_array = unserialize($clientrow["bookmark"]);
            if ($bookmark_array) {
                $arraylenth = sizeof($bookmark_array);
                for ($i = 0; $i < $arraylenth; $i++) {
                    $sql1 = mysqli_query($connect, "SELECT * FROM `data` WHERE `id` = " . $bookmark_array[$i]);
                    $row = mysqli_fetch_assoc($sql1);
                    $output .= '
                  <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                    $offset++;
                }
            } else {
                $output = "<h3>No bookmark available!!</h3>";
            }
            $sql = "SELECT * FROM `data` WHERE `id` IN (NULL)";
        } else if ($_GET["action"] == "most view") {
            $notify = "Most view";
            $offset = 0;
            $sql = mysqli_query($connect, "SELECT * FROM `data` ORDER BY `views` DESC LIMIT $limit");
            while ($row = mysqli_fetch_assoc($sql)) {
                $output .= '
                   <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">Views: ' . $row['views'] . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                $offset++;
            }
            $sql = "SELECT * FROM `data` WHERE `id` IN (NULL)";
        } else if ($_GET["action"] == "most like") {
            $notify = "Most view";
            $offset = 0;
            $sql = mysqli_query($connect, "SELECT * FROM `data` ORDER BY `likes` DESC LIMIT $limit");
            while ($row = mysqli_fetch_assoc($sql)) {
                $output .= '
                   <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">Likes: ' . $row['likes'] . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                $offset++;
            }
            $sql = "SELECT * FROM `data` WHERE `id` IN (NULL)";
        } else if ($_GET["action"] == "pagination") {
            $search_quary = $_GET['search'];
            if (strlen($search_quary)>5) {
                $sql = "SELECT * FROM `data` WHERE `fullname` LIKE '%" . $search_quary . "%' OR `experience` LIKE '%" . $search_quary . "%' OR `education` LIKE '%" . $search_quary . "%' OR `contactinfo` LIKE '%" . $search_quary . "%' OR `smalldesc` LIKE '%" . $search_quary . "%' OR `id` LIKE '%" . $search_quary . "%' ORDER BY `time` DESC ";
            } else {
                $sql = $_GET['sql'];
            }
            $offset = $_GET['offset'];
            $result = mysqli_query($connect, $sql . "LIMIT $limit OFFSET $offset");
            while ($row = mysqli_fetch_assoc($result)) {
                $output .= '
                   <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                     <div>
                            <div class="rank">' . ($offset + 1)  . '.</div>
                        <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                        <div class="details">
                            <h3 class="name">' . $row['fullname'] . '</h3>
                            <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                            <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                        </div>
                    </div>
                    <div class="time-and-date">
                        <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                        <div class="date">' . date("d-m-y", $row['time']) . '</div>
                    </div>
                </a>
                    ';
                $offset++;
            }
        }
    } else {
        $sql = "SELECT * FROM `data`  ORDER BY `time` DESC ";
        $offset = 0;
        $result = mysqli_query($connect, $sql . "Limit $limit");
        while ($row = mysqli_fetch_assoc($result)) {
            $output .= '
               <a target="_blank" href="detailedLeadView.php?lead_id=' . $row['id'] . '" class="content">
                 <div>
                        <div class="rank">' . ($offset + 1)  . '.</div>
                    <div class="photo"><img src="dataImages/' . $row['photo'] . '" class="lead-photo-home" alt="Lead Photo"></div>
                    <div class="details">
                        <h3 class="name">' . $row['fullname'] . '</h3>
                        <div class="experience">' .  substr($row['experience'], 2, 20) . '</div>
                        <div class="education">' . substr($row['education'], 2, 20)  . '</div>
                    </div>
                </div>
                <div class="time-and-date">
                    <div class="time">' . date("h:i:sa", $row['time']) . '</div>
                    <div class="date">' . date("d-m-y", $row['time']) . '</div>
                </div>
            </a>
                ';
            $offset++;
        }
    }
}
echo mysqli_error($connect);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="/imgs/logo.png" />
</head>

<body>
    <header class="header container">
        <a href="index.php" class="logo"><img src="imgs/logo.png" alt="logo"></a>

        <nav class="navbar">
            <a href="home.php" class="active" style="--i:1;">Home</a>
            <a href="about/aboutlogedin.php" style="--i:2;">About</a>
            <a href="privacypolicy/privacypolicylogedin.php" style="--i:3;">Privacy Policy</a>
            <a href="contact/contactlogedin.php" style="--i:5;">Contact</a>
        </nav>
        <div class="account"><a href="login/logout.php" class="btn">Logout</a></div>
        <div class="ham-count-container">
            <a href="login/logout.php" class="btn">LogOut</a>
            <div class="hamburger">
                <span class="bar" id="line1"></span>
                <span class="line" id="line2"></span>
                <span class="line" id="line3"></span>
                <span class="bar" id="line4"></span>
            </div>
        </div>
    </header>
    <nav class="responsive-navber">
        <a href="about.php" style="--i:1;">Home</a>
        <a href="about/aboutlogedin.php" class="active" style="--i:2;">About</a>
        <a href="privacypolicy/privacypolicylogedin.php" style="--i:3;">Privacy Policy</a>
        <a href="contact/contactlogedin.php" style="--i:5;">Contact</a>
    </nav>
    <div class="cover"></div>


    <section class="top-container container">
        <h1 class="Title">Welcome <span><?php echo $clientrow["fullname"]; ?></span></h1>
        <form action="home.php?" method="get">
            <input type="text" name="search_query" class="search-bar" placeholder="Search Something...">
            <input type="hidden" name="action" value="search">
            <input type="submit" value="Search" class="search-btn">
        </form>
    </section>



    <div class="options"><a href="home.php">Recently added</a><a href="home.php?action=bookmark">bookmark</a><a href="home.php?action=most view">most view</a><a href="home.php?action=most like">most like</a></div>



    <div class="notify container">
        <h1 class="content-title"><?php if (isset($notify)) {
                                        echo $notify;
                                    } else {
                                        echo "Recently Added";
                                    } ?></h1>
        <hr>
    </div>

    <section class="data-container">
        <?php
        echo $output;
        ?>
    </section>
    <div style="padding: 0 10%">
        <hr>
    </div>
    <div class="pagenation">
        <?php
        $data_count = mysqli_num_rows(mysqli_query($connect, $sql));
        $pagenation_output = '';
        $searching;
        if(strlen($sql>300)){
            $searching = 1;
        }else{
            $searching = 0;
        }
        if ($data_count > $limit) {
            if (($offset - $limit) <= 0) {
                $pagenation_output = '<a href="home.php?sql=' . $sql . '&action=pagination&offset=' . ($offset) . '&search='.$search_quary.'">Next</a>';
            } else if ($offset >= $data_count) {
                $pagenation_output = '<a href="home.php?sql=' . $sql . '&action=pagination&offset=' . (floor($offset / $limit) - 1) . '&search='.$search_quary.'">Previous</a>';
            } else {
                $pagenation_output = '<a href="home.php?sql=' . $sql . '&action=pagination&offset=' . (floor($offset / $limit) - 1) . '&search='.$search_quary.'">Previous</a><a href="home.php?sql=' . $sql . '&action=pagination&offset=' . ($offset) . '&search='.$search_quary.'">Next</a>';
            }
        }
        echo $pagenation_output;
        ?>
    </div>


    <footer>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <div class="footer-text">
            <ul>
                <li><a href="about/aboutlogedin.php">About us</a></li>
                <li><a href="contact/contactlogedin.php">Contact us</a></li>
                <li><a href="privacypolicy/privacypolicylogedin.php">Privacy Policy</a></li>
            </ul>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="subscription/subscription.php">Subscriptions</a></li>
            </ul>
            <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
        </div>
        <style>
            .social-media-handler a {
                width: 20px;
                height: 20px;
                margin: 5px;
                padding: 10px;
                border-radius: 50%;
                background-color: white;
                color: black;
                font-size: 20px;
            }

            .social-media-handler a:hover {
                background-color: black;
                color: white;
            }

            .footer-text {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 1em;
            }

            .footer-text ul {
                display: flex;
                gap: 28px;
            }

            .footer-text ul li {
                font-size: 12px;
            }

            .footer-text ul li a {
                color: white;
            }

            .footer-text ul li a:hover {
                color: red;
            }

            .footer-text ul li:nth-child(1) {
                list-style-type: none;
            }
        </style>

    </footer>


</body>
<script src="main.js"></script>

</html>
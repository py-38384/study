<?php
if (isset($_COOKIE["account_id"])) {
    include "../config.php";
    $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
    $result = mysqli_query($connect, $sql);
    $exist = mysqli_num_rows($result);
    if ($exist == 1) {
        header("Location: aboutlogedin.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="about.css">
</head>

<body>
    <section>
        <header class="header container">
            <a href="../index.php" class="logo"><img src="../imgs/logo.png" alt="logo"></a>

            <nav class="navbar">
                <a href="../index.php" style="--i:1;">Home</a>
                <a href="about.php" class="active" style="--i:2;">About</a>
                <a href="../privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
                <a href="../contact/contact.php" style="--i:5;">Contact</a>
            </nav>
            <div class="account"><a href="../signup/signup.php" class="btn">SignUp</a><a href="../login/login.php" class="btn">Login</a></div>
            <div class="ham-count-container">
                <a href="../signup/signup.php" class="btn">SignUp</a><a href="../login/login.php" class="btn">Login</a>
                <div class="hamburger">
                    <span class="bar" id="line1"></span>
                    <span class="line" id="line2"></span>
                    <span class="line" id="line3"></span>
                    <span class="bar" id="line4"></span>
                </div>
            </div>
        </header>
        <nav class="responsive-navber">
            <a href="../index.php" class="active" style="--i:1;">Home</a>
            <a href="about.php" style="--i:2;">About</a>
            <a href="../privacypolicy/privacypolicy.php" style="--i:3;">Privacy Policy</a>
            <a href="../contact/contact.php" style="--i:5;">Contact</a>
        </nav>
        <div style="right:0;" class="cover"></div>
        <h1>About us</h1>
        <p>
            <p style="color:red;text-align:left">What are we?</p>
            <p>
                <ul>
                    <li>
                        Smart Data is a Best Lead Genaration Tool In The World. Smart Data Is A Plan
                        Based Website.
                    </li>
                    <li>
                        Welcome to Smart Data, your ultimate destination for intelligent lead
                        generation solutions. We are a cutting-edge technology company specializing in
                        harnessing the power of data to help businesses thrive in the digital age. Our mission
                        is to provide businesses with high-quality leads that drive growth, enhance sales
                        pipelines, and maximize their ROI.
                    </li>
                </ul>
            </p>
            <p style="color:red;text-align:left">what technology we use?</p>
            <p>
                <ul>
                    <li>
                        At Smart Data, we understand the critical importance of data in today's highly
                        competitive business landscape. We believe that data holds the key to unlocking
                        untapped potential and gaining a competitive edge. Our team of experts combines
                        their extensive knowledge and experience in data analytics, machine learning, and
                        lead generation to deliver actionable insights and exceptional results.
                    </li>
                    <li>
                        What sets us apart is our commitment to leveraging advanced technologies to collect,
                        analyze, and interpret data in real-time. Through our innovative solutions, we help
                        businesses identify their target audience, understand their needs, and engage with
                        them effectively. Our state-of-the-art algorithms and predictive modeling techniques
                        enable us to identify the most qualified leads, allowing our clients to focus their
                        resources on converting prospects into valuable customers.
                    </li>
                    <li>
                        We take pride in our data-driven approach, ensuring that the leads we generate are
                        highly relevant and tailored to our clients' specific requirements. Our sophisticated
                        lead scoring system enables us to prioritize leads based on their quality and likelihood
                        to convert, empowering our clients to optimize their sales and marketing efforts.
                    </li>
                </ul>
            </p>
            <p style="color:red;text-align:left">
                Why to choose us?
            </p>
            <p>
                At Smart Data, we value integrity, transparency, and trust. We prioritize the security
                and privacy of our clients' data, adhering to strict industry standards and regulations.
                Our robust data protection measures ensure that sensitive information is handled with
                the utmost care and confidentiality.
                Whether you are a small startup or a multinational corporation, our solutions are
                designed to scale with your business needs. We work closely with our clients,
                understanding their unique goals and challenges, to deliver personalized lead
                generation strategies that drive tangible results. Our dedicated support team is always
                available to provide assistance and guidance, ensuring a seamless experience
                throughout your engagement with us.
                Join us on the journey to harness the power of smart data and unlock the limitless
                potential for your business. Contact Smart Data today and let us help you accelerate
                your growth and achieve unparalleled success.
            </p>
        </p>
    </section>
    
    
    <footer>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <div class="footer-text">
        <ul>
            <li><a href="about.php">About us</a></li>
            <li><a href="../contact/contact.php">Contact us</a></li>
            <li><a href="../privacypolicy/privacypolicy.php">Privacy Policy</a></li>
        </ul>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="../subscription/subscription.php">Subscriptions</a></li>
        </ul>
        <p>Copyright &copy; 2023 by Smart Data | All Rights Reserved.</p>
    </div>
    <style>
        .social-media-handler a {
            width: 20px;
            height: 20px;
            margin: 5px;
            padding: 10px;
            border-radius: 50%;
            background-color: white;
            color: black;
            font-size: 20px;
        }
        .social-media-handler a:hover{
            background-color: black;
            color:  white;
        }
        .footer-text{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 1em;
        }
        .footer-text ul{
            display: flex;
            gap: 28px;
        }
        .footer-text ul li{
            font-size: 12px;
        }
        .footer-text ul li a{
            color: white;
        }
        .footer-text ul li a:hover{
            color: red;
        }
        .footer-text ul li:nth-child(1){
            list-style-type: none;
        }
    </style>

</footer>


</body>
<script src="../main.js"></script>

</html>
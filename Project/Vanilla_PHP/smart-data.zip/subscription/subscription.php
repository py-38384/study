<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Smart Data - Smart way to get business leads</title>
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
    <link rel="icon" type="image/png" href="../imgs/logo.png" />
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <div class="card-container">



      <a href="../signup/signup.php?sub=basic" class="card basic-card">
        <span></span>
        <div class="back-cover">
          <div class="back"></div>
          <div class="pack-name">Basic</div>
          <div class="price">
            $12.00
            <div>per month</div>
          </div>
          <ul>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Access to our comprehensive lead database.</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Email support</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-x"></i></div>
              <div class="text">
                Advanced lead filtering options with additional criteria.
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-x"></i></div>
              <div class="text">
                Integration with crm systems for seamless lead management
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-x"></i></div>
              <div class="text">
                Enhanced analytics and reporting capabilities.
              </div>
            </li>
          </ul>
        </div>
      </a>



      <a href="../signup/signup.php?sub=standard" class="card standard-card">
        <span></span>
        <div class="back-cover">
          <div class="back"></div>
          <div class="pack-name">Standard</div>
          <div class="price">
            $30.00
            <div>per month</div>
          </div>
          <ul>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Access to our comprehensive lead database.</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Email support</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">
                Advanced lead filtering options with additional criteria.
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">
                Integration with crm systems for seamless lead management
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-x"></i></div>
              <div class="text">
                Enhanced analytics and reporting capabilities.
              </div>
            </li>
          </ul>
        </div>
      </a>



      <a href="../signup/signup.php?sub=premium" class="card premium-card">
        <span></span>
        <div class="back-cover">
          <div class="back"></div>
          <div class="pack-name">Premium</div>
          <div class="price">
            $69.00
            <div>per month</div>
          </div>
          <ul>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Access to our comprehensive lead database.</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">Email support</div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">
                Advanced lead filtering options with additional criteria.
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">
                Integration with crm systems for seamless lead management
              </div>
            </li>
            <li>
              <div class="icon"><i class="bx bx-check"></i></div>
              <div class="text">
                Enhanced analytics and reporting capabilities.
              </div>
            </li>
          </ul>
        </div>
      </a>

    </div>
  </body>
</html>

<?php
function check()
{
    if (isset($_COOKIE["account_id"])) {
        include "config.php";
        $sql = "SELECT * FROM `account` WHERE `account_id` = '" . $_COOKIE["account_id"] . "'";
        $result = mysqli_query($connect, $sql);
        $clientrow = mysqli_fetch_assoc($result);
        $exist = mysqli_num_rows($result);
        if ($exist == 1) {
            if ($clientrow["accountstatus"] == "active") {
                return $clientrow;
            } else {
                setcookie("account_id", "null", time() + (86400 * 30), "/");
                header("Location: index.php");
            }
        } else {
            header("Location: index.php");
        }
    } else {
        header("Location: index.php");
    }
}
$clientrow = check();
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    check();
    if (isset($_GET["lead_id"])) {
        include "config.php";
        $lead_id = $_GET["lead_id"];
        $sql = mysqli_query($connect, "SELECT * FROM `data` WHERE `id` =  $lead_id");
        $row = mysqli_fetch_assoc($sql);
        mysqli_query($connect, "UPDATE `data` SET `views` = '" . ($row["views"] + 1) . "' WHERE `data`.`id` = " . $lead_id);
    } else {
        header("Location: home.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Data - Smart way to get business leads</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="image/png" href="/imgs/logo.png" />
    <link rel="stylesheet" href="style.css">
</head>
<style>
    body{
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
<body>

    <div class="lead-view-container">
        <div class="lead-container">
            <div class="back-button-div">
                <a class="btn" style="border-radius:0px;padding:5px 20px;z-index:100;pointer-events: auto;" href="home.php"><i class='bx bx-home-alt-2'></i></a>
                <div class="do-impression">
                    <?php
                        $like_sql = mysqli_query($connect,"SELECT * FROM `account` WHERE `account_id` = '".$_COOKIE["account_id"]."'");
                        $rowimpression = mysqli_fetch_assoc($like_sql);
                        $like_array = unserialize($rowimpression["like"]);
                        if($like_array){}else{
                            $like_array = array();
                        }
                        if(in_array($lead_id,$like_array)){
                            $like_style = "border:1px solid gray;background:rgb(79, 149, 255);";
                            $like_inner_html = "<i class='bx bxs-like'></i>";
                        }else{
                            $like_style = "border:1px solid gray;background:#E5E5E5";
                            $like_inner_html = "<i class='bx bx-like'></i>";
                        }

                        $bookmark_sql = mysqli_query($connect,"SELECT * FROM `account` WHERE `account_id` = '".$_COOKIE["account_id"]."'");
                        $bookmark_array = unserialize($rowimpression["bookmark"]);
                        if($bookmark_array){}else{
                            $bookmark_array = array();
                        }
                        if(in_array($lead_id,$bookmark_array)){
                            $bookmark_style = "border:1px solid gray;background:rgb(79, 149, 255);";
                            $bookmark_inner_html = "<i class='bx bxs-bookmarks'></i>";
                        }else{
                            $bookmark_style = "border:1px solid gray;background:#E5E5E5";
                            $bookmark_inner_html = "<i class='bx bx-bookmarks'></i>";
                        }
                    ?>
                    <div class="like-div"><button class="like" style = "<?php echo $like_style?>"><?php echo $like_inner_html?></button></div>
                    <div class="bookmark-div"><button class="bookmark" style = "<?php echo $bookmark_style?>"><?php echo $bookmark_inner_html?></button></div>
                </div>
            </div>
            <div class="top-lead-container lead-container-section">
                <div class="lead-photo"><img src="dataImages/<?php echo $row['photo'] ?>" alt="lead photo"></div>
                <div class="lead-name"><?php echo $row['fullname'] ?></div>
                <div class="smalldesc">( <?php echo $row['smalldesc'] ?>)</div>
                <div class="lead-impression">
                    <div class="lead_id"><small>Lead id: <?php echo $row['id'] ?></small></div>
                    <div class="impression">
                        <small class="views">views: <?php echo $row['views'] ?></small>
                        <small class="likes">likes: <?php echo $row['likes'] ?></small>
                    </div>
                </div>
            </div>
            <div class="experience lead-container-section">
                <h3>EXPERIENCES</h3><br>
                <?php
                $experience_output = '';
                $experience_array = explode('~', $row['experience'],);
                for ($i = 0; $i < count($experience_array); $i++) {
                    $individual_experience_array = explode(PHP_EOL, $experience_array[$i]);
                    if ($i == 0) {
                        $experience_output .= "<div style='border-bottom:1px solid #c2c2c2;padding-bottom:40px;border-top:1px solid #c2c2c2;'>";
                    } else {
                        $experience_output .= "<div style='border-bottom:1px solid #c2c2c2;padding-bottom:40px'>";
                    }
                    for ($j = 0; $j < count($individual_experience_array); $j++) {
                        if ($j == 0) {
                            $experience_output .= "<b>" . $individual_experience_array[$j] . "</b>";
                        } else {
                            $experience_output .= "<br><small>" . $individual_experience_array[$j] . "</small>";
                        }
                    }
                    $experience_output .= "</div>";
                }
                echo $experience_output;
                ?>
            </div>
            <div class="education lead-container-section">
                <h3>EDUCATION </h3><br>
                <div style='border-bottom:1px solid #c2c2c2;padding-bottom:40px;border-top:1px solid #c2c2c2;'>
                    <?php
                    $education_output = '';
                    $education_array = explode(PHP_EOL, $row['education']);
                    for ($j = 0; $j < count($education_array); $j++) {
                        if ($j == 0) {
                            $education_output .= "<b>" . $education_array[$j] . "</b>";
                        } else {
                            $education_output .= "<br><small>" . $education_array[$j] . "</small>";
                        }
                    }
                    echo $education_output;
                    ?>
                </div>
            </div>
            <div class="contactinfo lead-container-section">
                <h3>CONTACT INFO </h3><br>
                <div style='border-bottom:1px solid #c2c2c2;padding-bottom:40px;border-top:1px solid #c2c2c2;'>
                    <?php
                    $contact_output = '';
                    $contact_array = explode(PHP_EOL, $row['contactinfo']);
                    for ($j = 0; $j < count($contact_array); $j++) {
                        if ($j == 0) {
                            $contact_output .= "<b>" . $contact_array[$j] . "</b>";
                        } else {
                            $contact_output .= "<br><small>" . $contact_array[$j] . "</small>";
                        }
                    }
                    echo $contact_output;
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="related-data-container">
    </div>
    </div>
</body>
<script>
    let likebutton = document.querySelector(".like");
    let bookmarkbutton = document.querySelector(".bookmark");
    likebutton.addEventListener("click", (e) => {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "lead_responce_handler.php?action=like&account_id="+<?php echo $_COOKIE["account_id"]?>+"&id="+<?php echo $lead_id?>,true);
        xhr.onload = () => {
            if(xhr.readyState === XMLHttpRequest.DONE){
                if(xhr.readyState == 4 && xhr.status == 200) {
                    let res = xhr.response;
                    console.log(res);
                    if(res == "like added"){
                        likebutton.style.border = "1px solid gray";
                        likebutton.style.background = "rgb(79, 149, 255)";
                        likebutton.innerHTML = "<i class='bx bxs-like'></i>";
                    }else{
                        likebutton.style.background = "#E5E5E5";
                        likebutton.innerHTML = "<i class='bx bx-like' ></i>";
                    }
                }
            }
        }
        xhr.send();
    })
    bookmarkbutton.addEventListener("click", (e) => {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "lead_responce_handler.php?action=bookmark&account_id="+<?php echo $_COOKIE["account_id"]?>+"&id="+<?php echo $lead_id?>,true);
        xhr.onload = () => {
            if(xhr.readyState === XMLHttpRequest.DONE){
                if(xhr.readyState == 4 && xhr.status == 200) {
                    let res = xhr.response;
                    console.log(res);
                    if(res == "bookmarked added"){
                        bookmarkbutton.style.border = "1px solid gray";
                        bookmarkbutton.style.background = "rgb(79, 149, 255)";
                        bookmarkbutton.innerHTML = "<i class='bx bxs-bookmarks' ></i>";
                    }else{
                        bookmarkbutton.style.background = "#E5E5E5";
                        bookmarkbutton.innerHTML = "<i class='bx bx-bookmarks'></i>";
                    }
                }
            }
        }
        xhr.send();
    })
</script>

</html>
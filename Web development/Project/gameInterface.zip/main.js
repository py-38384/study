var btn_outline = '5px solid #8AC8FF';
function leftBtn(ele){
  ele.style.outline = btn_outline;
  setTimeout(()=>{
    ele.style.outline = 'none';
  },100);
  console.log('leftBtn clicked');
  
}
function rightBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none';
  }, 100);
  console.log('rightBtn clicked');
}
function topBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
  console.log('topBtn clicked')
}
function bottomBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
  console.log('bottomBtn clicked')
}

let broad = document.querySelector('#displayBoard');
let btn_outline = '5px solid #8AC8FF';
let lastPrintTime = 0;
let frameRate = 3;
let curBrick = [];
let isSet = false;
let index = 0;
let indexArr = [0, 0, 0, 0, 0, 0, 0];
let pause = false;
let gameOver = false;
let playing = true;

let ground = [{ x: 1, y: 27 }, { x: 2, y: 27 }, { x: 3, y: 27 }, { x: 4, y: 27 }, { x: 5, y: 27 }, { x: 6, y: 27 }, { x: 7, y: 27 }, { x: 8, y: 27 }, { x: 9, y: 27 }, { x: 10, y: 27 }, { x: 11, y: 27 }, { x: 12, y: 27 }, { x: 13, y: 27 }, { x: 14, y: 27 }, { x: 15, y: 27 }, { x: 16, y: 27 }, { x: 17, y: 27 }, { x: 18, y: 27 }];
let groundBrick = [];
let objArr = [
        [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }, { x: 0, y: 3 }],
        [{ x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }],
        [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 1 }, { x: 0, y: 2 }],
        [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
        [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }],
        [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
        [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
        ];
let Brick1Alt = [[{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 3, y: 0 }], [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }, { x: 0, y: 3 }]];
let Brick2Alt = [[{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }, { x: 0, y: 1 }], [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }, { x: 1, y: 1 }], [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x:2, y:0 }, { x: 1, y: 1 }], [{ x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }]];
let Brick3Alt = [[{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 1 }], [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 1 }, { x: 0, y: 2 }]];
let Brick4Alt = [[{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 0 }, { x: 2, y: 0 }], [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 2 }]];
let Brick5Alt = [[{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 2, y: 1 }], [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }, { x: 0, y: 2 }], [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }], [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }]];
let Brick6Alt = [[{ x: 2, y: 0 }, { x: 2, y: 1 }, { x: 1, y: 1 }, { x: 0, y: 1 }], [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 0, y: 2 }, { x: 1, y: 2 }], [{ x: 0, y: 1 }, { x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }], [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }]];
let Brick7Alt = [[{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }]];
/* 1st brick = *
               *
               *
               *
               
   2nd brick =  *
               ***
               
   3rd brick =  *
               **
               *
               
   4th brick = *
               **
                *
                
   5th brick = **
               *
               *
               
   6th brick = **
                *
                *
                
   7th brick = **
               **
      
 */


function leftBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none';
  }, 100);
  curBrick.forEach((e) => {
    e.x -= 1;
  });
  gameOver = false;
  playing = true;
  if (pause) {} else {
    if (document.getElementById('notice').innerText === 'GAME OVER') {
      document.getElementById('notice').style.display = 'none';
    }
    if (inputDir.x === 1 && inputDir.y === 0) {} else {
      inputDir = { x: -1, y: 0 };
    }
  }
}

function rightBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none';
  }, 100);
  curBrick.forEach((e) => {
    e.x += 1;
  })
  gameOver = false;
  playing = true;
  if (pause) {} else {
    if (document.getElementById('notice').innerText === 'GAME OVER') {
      document.getElementById('notice').style.display = 'none';
    }
    if (inputDir.x === -1 && inputDir.y === 0) {} else {
      inputDir = { x: 1, y: 0 };
    }
  }
}

function topBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100);
  let curY = 0
  switch (index - 1) {
    case 0:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick1Alt[indexArr[0]]));
      indexArr[0]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[0] >= Brick1Alt.length) { indexArr[0] = 0 }
      break;
    case 1:
      curY = curBrick[0].y;
      curX = curBrick[0].x - 1;
      curBrick = JSON.parse(JSON.stringify(Brick2Alt[indexArr[1]]));
      indexArr[1]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[1] >= Brick2Alt.length) { indexArr[1] = 0 }
      break;
    case 2:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick3Alt[indexArr[2]]));
      indexArr[2]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[2] >= Brick3Alt.length) { indexArr[2] = 0 }
      break;
    case 3:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick4Alt[indexArr[3]]));
      indexArr[3]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[3] >= Brick4Alt.length) { indexArr[3] = 0 }
      break;
    case 4:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick5Alt[indexArr[4]]));
      indexArr[4]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[4] >= Brick5Alt.length) { indexArr[4] = 0 }
      break;
    case 5:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick6Alt[indexArr[5]]));
      indexArr[5]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[5] >= Brick6Alt.length) { indexArr[5] = 0 }
      break;
    case 6:
      curY = curBrick[0].y;
      curX = curBrick[0].x;
      curBrick = JSON.parse(JSON.stringify(Brick7Alt[indexArr[6]]));
      indexArr[6]++;
      curBrick.forEach((e, i) => {
        curBrick[i].x = curBrick[i].x + curX;
        curBrick[i].y = curBrick[i].y + curY;
      });
      if (indexArr[6] >= Brick7Alt.length) { indexArr[6] = 0 }
      break;
  }
  gameOver = false;
  playing = true;
  if (pause) {} else {
    if (document.getElementById('notice').innerText === 'GAME OVER') {
      document.getElementById('notice').style.display = 'none';
    }
  }
}

function bottomBtn(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
  gameOver = false;
  playing = true;
  if (pause) {} else {
    if (document.getElementById('notice').innerText === 'GAME OVER') {
      document.getElementById('notice').style.display = 'none';
    }
  }
}

function pauseGame(ele) {
  ele.style.outline = btn_outline;
  setTimeout(() => {
    ele.style.outline = 'none'
  }, 100)
  if (gameOver) {} else {
    //document.getElementById('notice').innerText = 'GAME PAUSE';
    if (pause) {
      notice.style.display = 'none';
      pause = false;
    } else {
      notice.style.display = 'block';
      pause = true;
    }
  }
}

function main(ctime) {
  window.requestAnimationFrame(main);
  if ((ctime - lastPrintTime) / 1000 < 1 / frameRate) {
    return;
  }
  lastPrintTime = ctime;
  gameEngine();
}

function gameEngine() {
  if (!isSet) {
    curBrick = JSON.parse(JSON.stringify(objArr[index]));
    curBrick.forEach((e, i) => {
      curBrick[i].x = curBrick[i].x + 9;
      curBrick[i].y = curBrick[i].y + 1;
    });
    index++;
    isSet = true;
  } else {
    curBrick.forEach((e, i) => {
      curBrick[i].y += 1;
    })
  }
  if (index > 6) { index = 0 }
  broad.innerHTML = '';
  curBrick.forEach((e, index) => {
    let brickElement = document.createElement('div');
    brickElement.style.gridRowStart = e.y;
    brickElement.style.gridColumnStart = e.x;
    brickElement.style.backgroundColor = 'blue';
    broad.appendChild(brickElement);
  });
  ground.forEach((e) => {
    curBrick.forEach((ele) => {
      if (e.x === ele.x && e.y === ele.y) {
        isSet = false;
      }
    });
  });
}
window.requestAnimationFrame(main);
let timeObj = new Date();
let hours = timeObj.getHours();
let minutes = timeObj.getMinutes();
let seconds = timeObj.getSeconds();
let container = document.querySelector('.container');
let timeStr = hours + ':' + minutes + ':' + seconds;

/*You can set the time manually by overriding the variables
hours = 23;
minutes = 59;
seconds = 55;*/

setInterval(() => {
  if (seconds >= 60) {
    seconds = 0;
    minutes++;
    if (minutes >= 60) {
      hours++;
      minutes = 0;
      if (hours >= 24) {
        hours = 0;
      }
    }
  }
  if (hours < 12) {
    if (hours === 0) {
      hours = 12
    }
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    if (hours < 10) {
      hours = '0' + hours;
    }
    var timeStr = hours + ':' + minutes + ':' + seconds + ' AM';
    seconds = Number(seconds);
    minutes = Number(minutes);
    hours = Number(hours);
    if (hours === 12) {
      hours = 0;
    }
  } else if (hours >= 12) {
    hours -= 12;
    if(hours === 0){
      hours = 12;
    }
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    if (hours < 10) {
      hours = '0' + hours;
    }
    var timeStr = hours + ':' + minutes + ':' + seconds + ' PM';
    seconds = Number(seconds);
    minutes = Number(minutes);
    hours = Number(hours);
    if(hours === 12){
      hours = 0;
    }
    hours += 12;
  }
  container.innerHTML = timeStr;
  seconds++;
}, 1000)
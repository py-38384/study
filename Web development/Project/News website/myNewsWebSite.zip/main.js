let xhr = new XMLHttpRequest();
xhr.open('GET', 'https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=92376e005b4c4baea5c368feb5793244', true);

xhr.onload = function() {
  let container = document.querySelector('.container');
  if (this.status == 200) {
    let data = JSON.parse(this.responseText);
    let articles = data['articles'];
    console.log(articles[0]['title']);
    let html = '';
    articles.forEach((element,index) => {
      html += `<div><a href="${articles[index]['url']}"><h1>${articles[index]['title']}</h1></a>
          <p>${articles[index]['content']}
          <a href="${articles[index]['url']}"><b>Read more</b></a>
        <p/></div>`;
    });
    container.innerHTML = html;
  } else {
    container.innerText = "Some error occurred!";
  }
}
xhr.send();
